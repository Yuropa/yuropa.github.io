//
//  MagicParticleEmitter2.cpp
//  A0
//
//  Created by Josh Ford on 9/22/15.
//  Copyright © 2015 Josh Ford. All rights reserved.
//

#include "MagicParticleEmitter2.h"

MagicParticleEmitter2::MagicParticleEmitter2(float radius) : FireParticleEmmitter(radius) {
    setParticleLifetime(20.0);
}

void MagicParticleEmitter2::updateParticle(Particle &p, float &lifetime, vec3 &velocity, float dt) {
    FireParticleEmmitter::updateParticle(p, lifetime, velocity, dt);
    
    velocity.x = (randomFloat() - 0.5) * 4.0;
    velocity.z = (randomFloat() - 0.5) * 4.0;
    
    float amount = lifetime / getParticeLifetime();
    vec3 color = (vec3(1.0, 0.0, 1.0)* 0.05).lerp(vec3(0.3, 0.8, 1.0) * 0.1, amount*amount);
    p.red = color.x;
    p.green = color.y;
    p.blue = color.z;
}
void MagicParticleEmitter2::updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position) {
    FireParticleEmmitter::updateGeneratedParticle(p, lifetime, velocity, position);
    
    vec3 color = vec3(1.0, 0.0, 1.0);
    p.red = color.x;
    p.green = color.y;
    p.blue = color.z;
}
