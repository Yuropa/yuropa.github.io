
#ifndef FireParticleEmmitter_hpp
#define FireParticleEmmitter_hpp

#include "ParticleEmitter.h"

class FireParticleEmmitter: public ParticleEmitter {    
public:
    FireParticleEmmitter(float radius);
    virtual void updateParticle(Particle &p, float &lifetime, vec3 &velocity, float dt);
    virtual void updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position);
    
    virtual void draw(const mat4 &projectionTransform);
};

#endif /* FireParticleEmmitter_hpp */
