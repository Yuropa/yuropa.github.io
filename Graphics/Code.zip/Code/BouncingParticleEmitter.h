
#ifndef BouncingParticleEmitter_hpp
#define BouncingParticleEmitter_hpp

#include "ParticleEmitter.h"

class BouncingParticleEmitter : public ParticleEmitter {
public:
    BouncingParticleEmitter(float radius);
    virtual void updateParticle(Particle &p, float &lifetime, vec3 &velocity, float dt);
    virtual void updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position);
};

#endif /* BouncingParticleEmitter_hpp */
