#include <iostream>
#include <SDL2/SDL_opengl.h>
#include "App.h"
#include "Node.h"
#include "BouncingParticleEmitter.h"
#include "FireParticleEmitter.h"
#include "MagicParticleEmitter.h"
#include "SmokeParticleEmitter.h"
#include "MagicParticleEmitter2.h"
#include "Cube.h"
#include "Ball.h"

#define STRINGIFY(x) #x
const std::string ballVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
);
const std::string ballFragmentShader =
STRINGIFY(
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              vec3 l = normalize(vec3(0.0, 0.0, 100.0) - v_position);
              vec4 color = vec4(0.0, 0.3, 0.8, 1.0) * (max(dot(v_normal, l), 0.0) + 0.4);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
);

const string floorVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          attribute vec2 a_texCoord;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec2 v_uv;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              v_uv = a_texCoord;
              gl_Position = u_projection * pos;
          }
);
const string floorFragmentShader =
STRINGIFY(
          uniform sampler2D u_tex;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec2 v_uv;
          void main() {
              vec3 l = normalize(vec3(0.0, 0.0, 100.0) - v_position);
              vec4 color = texture2D(u_tex, v_uv) * (max(dot(v_normal, l), 0.0) + 0.4);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
);

App::App() {
    rootNode = shared_ptr<Node>(new Node());
    rootNode->name = "root";
    camera = shared_ptr<Camera>(new Camera(1.33, 0.1, 1000.0));
    camera->name = "camera";
    rootNode->addChildNode(camera);
    camera->translateTo(vec3(0.0, 3.0, 3.0));
    camera->rotateTo(vec3(M_PI * 0.5, 0.0, 0.0));
    running = true;
}

void App::setup() {
    glClearColor( 0.f, 0.f, 0.f, 1.f );
    
    glEnable(GL_DEPTH_TEST);
    GetGLError();
    
    // glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
    GetGLError();
    
    GLenum error = glGetError();
    if( error != GL_NO_ERROR ) {
        std::cout << "Error initializing OpenGL! " << std::endl;
    }
    
    handleKeyPress(SDLK_1, false);
}

void App::resizeTo(int width, int height) {
    // Adjust Viewport
    glViewport(0,0, width, height);
    
    // Update projection matrix
    float aspect = (float)width / (float)height;
    camera->setAspect(aspect);
}

void App::resetScene() {
    rootNode->removeAllChildren();
}

void* floorEmitterUpdate1 = &floorEmitterUpdate1;
void* floorEmitterUpdate2 = &floorEmitterUpdate2;
Uint32 timerCallback(Uint32 interval, void *param) {
    SDL_Event event;
    SDL_UserEvent userevent;
    
    userevent.type = SDL_USEREVENT;
    userevent.code = 0;
    userevent.data1 = param;
    userevent.data2 = NULL;
    
    event.type = SDL_USEREVENT;
    event.user = userevent;
    
    SDL_PushEvent(&event);
    return 0;
}
void App::handleKeyPress(SDL_Keycode key, bool repeat) {
    const float movement = 0.025;
    if (key == SDLK_UP) {
        camera->translateBy(vec3(0.0, movement, 0.0));
    } else if (key == SDLK_DOWN) {
        camera->translateBy(vec3(0.0, -movement, 0.0));
    } else if (key == SDLK_LEFT) {
        camera->translateBy(vec3(-movement, 0.0, 0.0));
    } else if (key == SDLK_RIGHT) {
        camera->translateBy(vec3(movement, 0.0, 0.0));
    } else if (key == SDLK_EQUALS) {
        camera->translateBy(vec3(0.0, 0.0, -movement));
    } else if (key == SDLK_MINUS) {
        camera->translateBy(vec3(0.0, 0.0, movement));
    } else if (key == SDLK_1) {
        resetScene();
        
        shared_ptr<Cube> cube = shared_ptr<Cube>(new Cube(5.0, 5.0, 1.0, 1, 1, 1));
        shared_ptr<Node> floor = shared_ptr<Node>(new Node());
        floor->name = "floor";
        floor->setGeometry(cube);
        floor->setTexture(shared_ptr<Texture>(new Texture("Textures/wood.jpg")));
        rootNode->addChildNode(floor);
        floor->translateTo(vec3(0.0, 0.0, -0.5));
        
        shared_ptr<Program> floorShader(new Program());
        floorShader->bindAttribute(PositionAttributeLocation, PositionAttribute);
        floorShader->bindAttribute(NormalAttributeLocation, NormalAttribute);
        floorShader->bindAttribute(TexCoordAttributeLocation, TexCoordAttribute);
        floorShader->buildProgram(floorVertexShader, floorFragmentShader);
        floor->setProgram(floorShader);
        
        shared_ptr<Program> ballShader = shared_ptr<Program>(new Program());
        ballShader->bindAttribute(PositionAttributeLocation, PositionAttribute);
        ballShader->bindAttribute(NormalAttributeLocation, NormalAttribute);
        ballShader->buildProgram(ballVertexShader, ballFragmentShader);
        
        shared_ptr<Ball> ball = shared_ptr<Ball>(new Ball(vec3(0.0, 0.0, 0.0)));
        ball->name = "ball";
        ball->setProgram(ballShader);
        rootNode->addChildNode(ball);
        ball->translateTo(vec3(0.0, 0.0, 5.0));
    } else if (key == SDLK_2) {
        resetScene();
        
        shared_ptr<Cube> cube = shared_ptr<Cube>(new Cube(15.0, 5.0, 1.0, 1, 1, 1));
        shared_ptr<Node> floor = shared_ptr<Node>(new Node());
        floor->name = "floor";
        floor->setTexture(shared_ptr<Texture>(new Texture("Textures/wood.jpg")));
        floor->setGeometry(cube);
        rootNode->addChildNode(floor);
        floor->translateTo(vec3(0.0, 0.0, -0.5));
        
        shared_ptr<Program> floorShader(new Program());
        floorShader->bindAttribute(PositionAttributeLocation, PositionAttribute);
        floorShader->bindAttribute(NormalAttributeLocation, NormalAttribute);
        floorShader->bindAttribute(TexCoordAttributeLocation, TexCoordAttribute);
        floorShader->buildProgram(floorVertexShader, floorFragmentShader);
        floor->setProgram(floorShader);
        
        shared_ptr<BouncingParticleEmitter> emitter = shared_ptr<BouncingParticleEmitter>(new BouncingParticleEmitter(0.2));
        emitter->name = "flood";
        rootNode->addChildNode(emitter);
        emitter->translateTo(vec3(-1.8, 0.0, 1.0));
        
        SDL_AddTimer(8000, &timerCallback, floorEmitterUpdate1);
        SDL_AddTimer(14000, &timerCallback, floorEmitterUpdate2);
    } else if (key == SDLK_3) {
        resetScene();
        
        shared_ptr<SmokeParticleEmitter> smokeEmitter = shared_ptr<SmokeParticleEmitter>(new SmokeParticleEmitter(0.5));
        smokeEmitter->name = "smoke";
        rootNode->addChildNode(smokeEmitter);
        smokeEmitter->translateTo(vec3(0.0, -0.75, 0.7));
        
        shared_ptr<FireParticleEmmitter> fireEmiiter = shared_ptr<FireParticleEmmitter>(new FireParticleEmmitter(0.5));
        fireEmiiter->name = "fire";
        rootNode->addChildNode(fireEmiiter);
        fireEmiiter->translateTo(vec3(0.0, -0.75, 0.7));
    } else if (key == SDLK_4) {
        resetScene();
        
        shared_ptr<MagicParticleEmitter> emitter = shared_ptr<MagicParticleEmitter>(new MagicParticleEmitter());
        emitter->name = "magic";
        emitter->translateTo(vec3(-3.0, 0.5, 1.0));
        rootNode->addChildNode(emitter);
    } else if (key == SDLK_5) {
        resetScene();
        
        shared_ptr<MagicParticleEmitter2> magicEmitter = shared_ptr<MagicParticleEmitter2>(new MagicParticleEmitter2(0.5));
        magicEmitter->name = "magic";
        rootNode->addChildNode(magicEmitter);
        magicEmitter->translateTo(vec3(0.0, -0.75, 3.0));
    } else if (key == SDLK_r) {
        camera->translateTo(vec3(0.0, 3.0, 3.0));
        camera->rotateTo(vec3(M_PI * 0.5, 0.0, 0.0));
    } else if (key == SDLK_SPACE) {
        running = !running;
    }
}
void App::handleKeyRelease(SDL_Keycode key) {
    
}
void App::handleMouseMove(int changeX, int changeY, int buttons) {
    if (buttons == SDL_BUTTON_LEFT) {
        // Rotate the view
        float factor = 0.005;
        camera->rotateBy(vec3(-changeY * factor, changeX * factor, 0.0));
        // camera->translateBy(vec3(-changeX * factor, changeY * factor, 0.0));
    }
}

void App::handleUserEvent(void* data) {
    if (data == floorEmitterUpdate1) {
        shared_ptr<Node> node = rootNode->childWithName("flood");
        if (node) {
            shared_ptr<BouncingParticleEmitter> emitter = dynamic_pointer_cast<BouncingParticleEmitter>(node);
            emitter->setEmissionRate(0);
        }
    } else if (data == floorEmitterUpdate2) {
        shared_ptr<Node> node = rootNode->childWithName("flood");
        if (node) {
            shared_ptr<BouncingParticleEmitter> emitter = dynamic_pointer_cast<BouncingParticleEmitter>(node);
            emitter->setEmissionRate(2000);
        }
    }
}

void App::update(float dt) {
    if (!running) {
        return;
    }
    rootNode->update(dt);
}

void App::draw() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);    
    
    rootNode->draw(camera->viewMatrix() * camera->projectionMatrix());
    
    GetGLError();
}