
#include "Ball.h"

const float radius = 0.5;

Ball::Ball(vec3 initalVelocity) {
    velocity = initalVelocity;
    
    shared_ptr<Sphere> sphere = shared_ptr<Sphere>(new Sphere(radius));
    setGeometry(sphere);
}

void Ball::update(float dt) {
    const vec3 acceleration = vec3(0.0, 0.0, -2.0);
    velocity = velocity + acceleration * dt;
    vec3 pos = getPosition();
    
    pos = pos + velocity * dt;
    if (pos.z < radius) {
        pos.z = radius;
        velocity.z = velocity.z * -0.6;
    }
    
    translateTo(pos);
}
