
#ifndef vec2_h
#define vec2_h


#include <cmath>

class vec2 {
public:
    float x, y;
    
    inline vec2(float x, float y) {
        this->x = x;
        this->y = y;
    }
    
    inline vec2(float value) {
        x = y = value;
    }
    
    inline vec2() : vec2(0.0) {}
    
    inline vec2 operator+(vec2 vec) const {
        return vec2(x + vec.x, y + vec.y);
    }
    
    inline vec2 operator-() const {
        return vec2(-x, -y);
    }
    
    inline vec2 operator-(vec2 vec) const {
        return vec2(x - vec.x, y - vec.y);
    }
    
    inline vec2 operator*(vec2 vec) const {
        return vec2(x * vec.x, y * vec.y);
    }
    
    inline vec2 operator/(vec2 vec) const {
        return vec2(x / vec.x, y / vec.y);
    }
    
    inline float dot(vec2 vec) const {
        return x*vec.x + y*vec.y;
    }
    
    inline float length() const {
        return sqrtf(dot(*this));
    }
    
    inline vec2 normalize() const {
        float l = length();
        return vec2(x/l, y/l);
    }
    
    inline float distanceTo(vec2 v) const {
        return (v - *this).length();
    }
    
    inline bool operator==(vec2 v) const {
        return  x == v.x && y == v.y;
    }
    
    inline vec2 lerp(vec2 end, float t) {
        return *this * (1.0 - t) + end * t;
    }
};

inline vec2 operator/(vec2 v, float a) {
    return vec2(v.x/a, v.y/a);
}

inline vec2 operator*(vec2 v, float a) {
    return vec2(v.x*a, v.y*a);
}

inline vec2 operator*(float a, vec2 v) {
    return vec2(v.x*a, v.y*a);
}


#endif /* vec2_h */
