
#ifndef MagicParticleEmitter_hpp
#define MagicParticleEmitter_hpp

#include "ParticleEmitter.h"

class MagicParticleEmitter : public ParticleEmitter {
public:
    MagicParticleEmitter();
    virtual void updateParticle(Particle &p, float &lifetime, vec3 &velocity, float dt);
    virtual void updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position);
};

#endif /* MagicParticleEmitter_hpp */
