
#ifndef Ball_hpp
#define Ball_hpp

#include "Node.h"

class Ball : public Node {
    vec3 velocity;
    
public:
    Ball(vec3 initalVelocity);
    
    virtual void update(float dt);
};

#endif /* Ball_hpp */
