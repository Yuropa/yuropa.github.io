
#include "FireParticleEmitter.h"

#define STRINGIFY(x) #x
const std::string vertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          attribute vec3 a_offset;
          attribute vec4 a_ambientColor;
          attribute vec2 a_texCoord;
          attribute float a_diffuseAmount;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec4 v_diffuseColor;
          varying vec4 v_ambientColor;
          varying vec2 v_texCoord;
          void main() {
              v_ambientColor = a_ambientColor;
              v_diffuseColor = a_ambientColor * a_diffuseAmount;
              v_texCoord = a_texCoord;
              
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(0.0, 0.0, 0.0, 1.0) + vec4(a_position + a_offset, 0.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
          );
const std::string fragmentShader =
STRINGIFY(
          uniform sampler2D u_tex;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec4 v_diffuseColor;
          varying vec4 v_ambientColor;
          varying vec2 v_texCoord;
          void main() {
              vec3 l = normalize(vec3(0.0, 0.0, 100.0) - v_position);
              vec4 diffuse = v_diffuseColor * (max(dot(v_normal, l), 0.0));
              vec4 ambient = v_ambientColor * texture2D(u_tex, v_texCoord);
              gl_FragColor = clamp(diffuse + ambient, 0.0, 1.0);
          }
          );

const GLint ParticlePosition      = TexCoordAttributeLocation + 1;
const GLint ParticleAmbientColor  = ParticlePosition + 1;
const GLint ParticleDiffuseAmount = ParticleAmbientColor + 1;

FireParticleEmmitter::FireParticleEmmitter(float radius) : ParticleEmitter(radius) {    
    setInitialVelocity(vec3(0.0, 0.0, 0.4));
    setEmissionRate(100.0);
    setParticleLifetime(10.0);
    
    shared_ptr<Geometry> geo = shared_ptr<Geometry>(new Geometry());
    const GLfloat size = 0.5;
    geo->addVertex(vec3(-size/2.0, 0.0, size/2.0),  vec3(0.0, 1.0, 0.0), vec2(0.0, 0.0));
    geo->addVertex(vec3( size/2.0, 0.0, size/2.0),  vec3(0.0, 1.0, 0.0), vec2(1.0, 0.0));
    geo->addVertex(vec3(-size/2.0, 0.0, -size/2.0), vec3(0.0, 1.0, 0.0), vec2(0.0, 1.0));
    geo->addVertex(vec3( size/2.0, 0.0, -size/2.0), vec3(0.0, 1.0, 0.0), vec2(1.0, 1.0));
    
    geo->addIndex(0);
    geo->addIndex(2);
    geo->addIndex(1);
    
    geo->addIndex(1);
    geo->addIndex(2);
    geo->addIndex(3);
    
    geo->prepareForRendering();
    
    shared_ptr<Program> program = shared_ptr<Program>(new Program());
    program->bindAttribute(PositionAttributeLocation, PositionAttribute);
    program->bindAttribute(NormalAttributeLocation, NormalAttribute);
    
    program->bindAttribute(ParticlePosition, "a_offset");
    program->bindAttribute(ParticleAmbientColor, "a_ambientColor");
    program->bindAttribute(ParticleDiffuseAmount, "a_diffuseAmount");
    
    program->buildProgram(vertexShader, fragmentShader);
    setProgram(program);
    
    setGeometry(geo);
    setTexture(shared_ptr<Texture>(new Texture("textures/fire.png")));
}

void FireParticleEmmitter::updateParticle(Particle &p, float &lifetime, vec3 &velocity, float dt) {
    lifetime += 2.0 * dt * randomFloat();
    
    ParticleEmitter::updateParticle(p, lifetime, velocity, dt);
    
    float amount = lifetime / getParticeLifetime();
    vec3 color = vec3(0.9, 0.86, 0.45).lerp(vec3(1.0, 0.55, 0.1), amount*amount) * 0.05;
    p.red = color.x;
    p.green = color.y;
    p.blue = color.z;
}

void FireParticleEmmitter::updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position) {
    ParticleEmitter::updateGeneratedParticle(p, lifetime, velocity, position);
    
    vec3 center = getPosition();
    velocity = (center - position) * randomFloat() * 1.2;
    velocity.z = 0.4;
    p.z = position.z * 0.1;
    
    p.red = 0.9;
    p.green = 0.86;
    p.blue = 0.45;
    p.alpha = 1.0;
    
    p.diffuseAmount = 0.0;
}

void FireParticleEmmitter::draw(const mat4 &projectionTransform) {
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ONE);
    
    ParticleEmitter::draw(projectionTransform);
    
    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
}
