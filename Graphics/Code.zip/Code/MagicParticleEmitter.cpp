
#include "MagicParticleEmitter.h"

vec3 velocityForTime(float time, float offset, float radius) {
    return vec3(0.3, sin(time + offset) * radius, cos(time + offset) * radius);
}

MagicParticleEmitter::MagicParticleEmitter() : ParticleEmitter(0.01) {
    setEmissionRate(300.0);
    setInitialVelocity(vec3(0.0));
    setParticleLifetime(40.0);
}

void MagicParticleEmitter::updateParticle(Particle &p, float &lifetime, vec3 &velocity, float dt) {
    dt *= 2.0;
    
    velocity = velocityForTime(lifetime, p.red, p.green);
    
    ParticleEmitter::updateParticle(p, lifetime, velocity, dt);
    
    p.green += 0.15 * dt;
    
    vec3 color = vec3(1.0, 0.0, 1.0).lerp(vec3(0.0, 1.0, 0.0), lifetime / getParticeLifetime());
    p.blue = color.z;
}
void MagicParticleEmitter::updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position) {
    ParticleEmitter::updateGeneratedParticle(p, lifetime, velocity, position);
    
    p.red = (rand() % 4) * M_PI / 2.0;
    p.green = 0;
    
    velocity = velocityForTime(0.0, p.red, p.green);
    
    p.diffuseAmount = 0.3;
}
