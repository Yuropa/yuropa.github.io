
#include "BouncingParticleEmitter.h"

BouncingParticleEmitter::BouncingParticleEmitter(float radius) : ParticleEmitter(radius) {
    setInitialVelocity(vec3(0.0, 0.0, 2.0));
    setEmissionRate(20.0);
    setParticleLifetime(13.0);
}

void BouncingParticleEmitter::updateParticle(Particle &p, float &lifetime, vec3 &velocity, float dt) {
    // Add the influence of gravity
    velocity.z += -2.0 * dt;
    
    vec3 pos = getPosition();
    if (p.z < 0.03 - pos.z) {
        p.z = 0.03 - pos.z;
        velocity.z = velocity.z * -0.6;
    }
    
    ParticleEmitter::updateParticle(p, lifetime, velocity, dt);
}

void BouncingParticleEmitter::updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position) {
    ParticleEmitter::updateGeneratedParticle(p, lifetime, velocity, position);
    
    velocity.x = 0.8 + randomFloat() * 0.05;
    velocity.z += randomFloat() * 0.1;
}
