
#include "OpenGL.h"
#include "Math.h"
#include <SDL2/SDL.h>
#include "Node.h"
#include "Camera.h"

class App {
    mat4 projectionMtx;
    shared_ptr<Node> rootNode;
    shared_ptr<Camera> camera;
    bool running;
    
    void resetScene();
public:
    App();
    ~App() {};
    
    void handleKeyPress(SDL_Keycode key, bool repeat);
    void handleKeyRelease(SDL_Keycode key);
    void handleMouseMove(int changeX, int changeY, int buttons);
    void handleUserEvent(void* data);
    
    void setup();
    void resizeTo(int width, int height);
    
    void update(float dt);
    void draw();
};