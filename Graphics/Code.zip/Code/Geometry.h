
#ifndef Geometry_hpp
#define Geometry_hpp

#include <vector>
#include <stdio.h>
#include "Math.h"
#include "OpenGL.h"

class Geometry {
    std::vector<GLfloat> data;
    std::vector<GLuint>  indicies;
    bool prepared;
#ifdef __APPLE__
    GLuint vao;
#endif
    GLuint dataBuf;
    GLuint indexBuf;
public:
    Geometry();
    ~Geometry();
    Geometry(Geometry &geo);
    
    void addVertex(vec3 position, vec3 normal, vec2 textCoord);
    void addIndex(int index);
    // This only needs to be called once, after which vertex and index data cannot be modified
    void prepareForRendering();
    
    void bind();
    void unbind();
    void draw();
    void drawInstancedCount(GLsizei count);
};

#endif /* Geometry_hpp */
