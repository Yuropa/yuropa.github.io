
#ifndef SmokeParticleEmitter_h
#define SmokeParticleEmitter_h

#include "FireParticleEmitter.h"

class SmokeParticleEmitter : public FireParticleEmmitter {
public:
    SmokeParticleEmitter(float radius);
    virtual void updateParticle(Particle &p, float &lifetime, vec3 &velocity, float dt);
    virtual void updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position);
};

#endif /* SmokeParticleEmitter_h */
