
#ifndef MagicParticleEmitter2_hpp
#define MagicParticleEmitter2_hpp

#include "FireParticleEmitter.h"

class MagicParticleEmitter2: public FireParticleEmmitter {
public:
    MagicParticleEmitter2(float radius);
    
    virtual void updateParticle(Particle &p, float &lifetime, vec3 &velocity, float dt);
    virtual void updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position);
};

#endif /* MagicParticleEmitter2_hpp */
