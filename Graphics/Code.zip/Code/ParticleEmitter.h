
#ifndef ParticleEmitter_hpp
#define ParticleEmitter_hpp

#include "Node.h"

float randomFloat();

typedef struct {
    GLfloat x, y, z;
    GLfloat red, green, blue, alpha;
    GLfloat diffuseAmount;
} Particle;

class ParticleEmitter : public Node {
    vec3 initialVelocity;
    float particleLifetime;
    float emissionRate;
    vector<Particle> particles;
    vector<float> lifetime;
    vector<vec3> velocity;
    float radius;
    GLuint positionVBO;
    shared_ptr<Texture> whiteTexture;
    
    void generateParticle();
public:
    ParticleEmitter(float radius);
    ~ParticleEmitter();
    
    void setInitialVelocity(vec3 initialVelocity);
    vec3 getInitialVelocity();
    
    void setParticleLifetime(float particleLifetime);
    float getParticeLifetime();
    
    void setEmissionRate(float emissionRate);
    float getEmissionRate();
    
    virtual void update(float dt);
    virtual void draw(const mat4 &projectionTransform);
    virtual void updateParticle(Particle &p, float &lifetime, vec3 &velocity, float dt);
    virtual void updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position);
};

#endif /* ParticleEmitter_hpp */
