
#include "SmokeParticleEmitter.h"

SmokeParticleEmitter::SmokeParticleEmitter(float radius) : FireParticleEmmitter(radius) {
     setParticleLifetime(25.0);
}

void SmokeParticleEmitter::updateParticle(Particle &p, float &lifetime, vec3 &velocity, float dt) {
    lifetime += 2.0 * dt * randomFloat();
    
    ParticleEmitter::updateParticle(p, lifetime, velocity, dt);
    
    float amount = lifetime / getParticeLifetime();
    vec4 color = vec4(0.9, 0.9, 0.9, 1.0).lerp(vec4(0.3, 0.3, 0.3, 0.0), amount) * 0.05;
    p.red = color.x;
    p.green = color.y;
    p.blue = color.z;
    p.alpha = color.w;
}
void SmokeParticleEmitter::updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position) {
    ParticleEmitter::updateGeneratedParticle(p, lifetime, velocity, position);
    
    vec3 center = getPosition();
    velocity = (center - position) * randomFloat() * 1.2;
    velocity.z = 0.8;
    p.z = position.z * 0.1;
    
    p.red = 0.9;
    p.green = 0.9;
    p.blue = 0.9;
    p.alpha = 1.0;
    
    p.diffuseAmount = 0.0;
}

