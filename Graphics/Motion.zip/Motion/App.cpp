#include <iostream>
#include <SDL2/SDL_opengl.h>
#include "App.h"
#include "Node.h"
#include "Cube.h"
#include "Cloth.h"
#include "Ball.h"
#include "SPHFluid.h"
#include "ShallowWater.h"
#include "MotionPlanner.h"

#define STRINGIFY(x) #x
const std::string ballVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
);
const std::string ballFragmentShader =
STRINGIFY(
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              vec3 l = normalize(vec3(0.0, 0.0, 100.0) - v_position);
              vec4 color = vec4(0.0, 0.3, 0.8, 1.0) * (max(dot(v_normal, l), 0.0) + 0.4);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
);

const string floorVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          attribute vec2 a_texCoord;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec2 v_uv;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              v_uv = a_texCoord;
              gl_Position = u_projection * pos;
          }
);
const string floorFragmentShader =
STRINGIFY(
          uniform sampler2D u_tex;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec2 v_uv;
          void main() {
              vec3 l = normalize(vec3(0.0, 0.0, 100.0) - v_position);
              vec4 color = texture2D(u_tex, v_uv) * (max(dot(v_normal, l), 0.0) + 0.4);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
);


const string obstacleVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
          );
const string obstacleFragmentShader =
STRINGIFY(
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              vec3 l = normalize(vec3(100.0, 0.0, 100.0) - v_position);
              vec4 color = vec4(0.1, 0.5, 0.3, 1.0) * (0.8 * max(dot(v_normal, l), 0.0) + 0.2);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
          );

App::App() {
    rootNode = shared_ptr<Node>(new Node());
    rootNode->name = "root";
    camera = shared_ptr<Camera>(new Camera(1.33, 0.1, 1000.0));
    camera->name = "camera";
    rootNode->addChildNode(camera);
    camera->translateTo(vec3(0.0, 0.0, 20.0));
    camera->rotateTo(vec3(0.0, 0.0, 0.0));
    running = true;
    justTransitioned = false;
    state = DefaultState;
    width = height = 0;
}

void App::setup() {
    glClearColor( 0.f, 0.f, 0.f, 1.f );
    
    glEnable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    GetGLError();
    
    glColor4f(0.2, 0.4, 1.0, 1.0);
    // glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
    GetGLError();
    
    GLenum error = glGetError();
    if( error != GL_NO_ERROR ) {
        std::cout << "Error initializing OpenGL! " << std::endl;
    }
    
    handleKeyPress(SDLK_r, false);
}

void App::resizeTo(int width, int height) {
    this->width = width;
    this->height = height;
    
    // Adjust Viewport
    glViewport(0,0, width, height);
    
    // Update projection matrix
    float aspect = (float)width / (float)height;
    camera->setAspect(aspect);
}

void App::resetScene() {
    rootNode->removeAllChildren();
}

void* floorEmitterUpdate1 = &floorEmitterUpdate1;
void* floorEmitterUpdate2 = &floorEmitterUpdate2;
Uint32 timerCallback(Uint32 interval, void *param) {
    SDL_Event event;
    SDL_UserEvent userevent;
    
    userevent.type = SDL_USEREVENT;
    userevent.code = 0;
    userevent.data1 = param;
    userevent.data2 = NULL;
    
    event.type = SDL_USEREVENT;
    event.user = userevent;
    
    SDL_PushEvent(&event);
    return 0;
}
void App::handleKeyPress(SDL_Keycode key, bool repeat) {
    if (key == SDLK_d) {
        shared_ptr<MotionPlanner> planer = dynamic_pointer_cast<MotionPlanner>(rootNode->childWithName("planner"));
        planer->setEnableDebug(!planer->enableDebug());
    } else if (key == SDLK_r) {
        resetScene();
        
        /*
        shared_ptr<Cube> cube = shared_ptr<Cube>(new Cube(20.0, 20.0, 1.0, 1, 1, 1));
        shared_ptr<Node> floor = shared_ptr<Node>(new Node());
        floor->name = "floor";
        floor->setGeometry(cube);
        floor->setTexture(shared_ptr<Texture>(new Texture("Textures/wood.jpg")));
        rootNode->addChildNode(floor);
        floor->translateTo(vec3(0.0, 0.0, -1.0));
        
        shared_ptr<Program> floorShader(new Program());
        floorShader->bindAttribute(PositionAttributeLocation, PositionAttribute);
        floorShader->bindAttribute(NormalAttributeLocation, NormalAttribute);
        floorShader->bindAttribute(TexCoordAttributeLocation, TexCoordAttribute);
        floorShader->buildProgram(floorVertexShader, floorFragmentShader);
        floor->setProgram(floorShader);
         */
        
        shared_ptr<MotionPlanner> planner = shared_ptr<MotionPlanner>(new MotionPlanner(20, 20));
        planner->name = "planner";
        rootNode->addChildNode(planner);
        planner->setStartPosition(vec2(-9, -9));
        planner->setEndPosition(vec2(9, 9));
        shared_ptr<CircleObstacle> obstacle = shared_ptr<CircleObstacle>(new CircleObstacle(vec2(0.0), 2.0));
        planner->addObstacle(obstacle);
        running = false;
        recomputePath = true;
        
        justTransitioned = true;
    } else if (key == SDLK_SPACE) {
        running = !running;
        
        if (recomputePath) {
            recomputePath = false;
            shared_ptr<MotionPlanner> planner = dynamic_pointer_cast<MotionPlanner>(rootNode->childWithName("planner"));
            planner->generateRoute();
        }
    } else if (key == SDLK_s) {
        recomputePath = true;
        state = StartPointState;
        shared_ptr<MotionPlanner> planner = dynamic_pointer_cast<MotionPlanner>(rootNode->childWithName("planner"));
    } else if (key == SDLK_e) {
        recomputePath = true;
        state = EndPointState;
        shared_ptr<MotionPlanner> planner = dynamic_pointer_cast<MotionPlanner>(rootNode->childWithName("planner"));
    } else if (key == SDLK_o) {
        recomputePath = true;
        state = ObstacleState;
        placingNode = shared_ptr<Node>(new Node());
        placingNode->setGeometry(shared_ptr<Sphere>(new Sphere(2.0)));
        
        shared_ptr<Program> obstalProgram = shared_ptr<Program>(new Program());
        obstalProgram->bindAttribute(PositionAttributeLocation, PositionAttribute);
        obstalProgram->bindAttribute(NormalAttributeLocation,   NormalAttribute);
        obstalProgram->buildProgram(obstacleVertexShader, obstacleFragmentShader);
        placingNode->setProgram(obstalProgram);
        
        rootNode->addChildNode(placingNode);
    }
}
void App::handleKeyRelease(SDL_Keycode key) {
    
}
void App::handleMouseMove(int changeX, int changeY, int buttons) {
    int x, y;
    SDL_GetMouseState(&x, &y);
    
    vec2 pos = vec2(x, y) - vec2(width, height) * 0.25;
    pos = pos * vec2(62.0 / width, -46.0 / height);
    
    shared_ptr<MotionPlanner> planner = dynamic_pointer_cast<MotionPlanner>(rootNode->childWithName("planner"));
    
    if (buttons == SDL_BUTTON_LEFT) {
        if (state == ObstacleState) {
            placingNode->removeFromParent();
            placingNode = nullptr;
            planner->addObstacle(shared_ptr<CircleObstacle>(new CircleObstacle(pos, 2.0)));
        }
        state = DefaultState;
    } else if (buttons == 0) {
        switch (state) {
                case ObstacleState:
                placingNode->translateTo(vec3(pos.x, pos.y, 0.0));
                break;
                case StartPointState:
                planner->setStartPosition(pos);
                break;
                case EndPointState:
                planner->setEndPosition(pos);
                break;
            default:
                break;
        }
        
        // Move the node
        if (placingNode) {
            placingNode->translateTo(vec3(pos.x, pos.y, 0.0));
        }
    }
}

void App::handleUserEvent(void* data) {
    
}

void App::update(float dt) {
    if (!running || justTransitioned) {
        justTransitioned = false;
        return;
    }
    rootNode->update(dt);
}

void App::draw() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);    
    
    rootNode->draw(camera->viewMatrix() * camera->projectionMatrix());
    
    GetGLError();
}