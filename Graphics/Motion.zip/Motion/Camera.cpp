
#include "Camera.h"

Camera::Camera(float aspect, float near, float far) {
    this->fov = 0.0;
    this->aspect = aspect;
    this->near = near;
    this->far = far;
    needsProjectionUpdate = true;
    
    setScale(1.0);
}
Camera::~Camera() {
    
}

void Camera::setAspect(float aspect) {
    needsProjectionUpdate = true;
    this->aspect = aspect;
}
float Camera::getAspect() {
    return aspect;
}
void Camera::setNear(float near) {
    needsProjectionUpdate = true;
    this->near = near;
}
float Camera::getNear() {
    return near;
}
void Camera::setFar(float far) {
    this->far = far;
}
float Camera::getFar() {
    return far;
}

void Camera::setScale(float scale) {
    this->scale = scale;
    this->fov = scale * 30.0;
    needsProjectionUpdate = true;
}

float Camera::getScale() {
    return scale;
}

void Camera::setNeedsWorldTransformUpdate() {
    Node::setNeedsWorldTransformUpdate();
    needsViewUpdate = true;
    needsProjectionUpdate = true;
}

mat4 Camera::viewMatrix() {
    if (needsViewUpdate) {
        mat4 transform = getWorldTransform();
        view = transform.invert();
        needsViewUpdate = false;
    }
    
    return view;
}

mat4 Camera::projectionMatrix() {
    if (needsProjectionUpdate) {
        float fovRadians = fov / 180.0 * M_PI;
        float cotan = 1.0 / tanf(fovRadians);
        projection = mat4(cotan / aspect, 0.0, 0.0, 0.0,
                          0.0, cotan, 0.0, 0.0,
                          0.0, 0.0, (far + near) / (near - far), -1.0,
                          0.0, 0.0, (2.0 * far * near) / (near - far), 0.0);
        needsProjectionUpdate = false;
    }
    
    return projection;
}
