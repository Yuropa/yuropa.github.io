
#include <fenv.h>
#include "Cube.h"
#include "ShallowWater.h"

#define MAX(x, y) (x > y ? x : y)

#define STRINGIFY(x) #x
const std::string vertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          attribute vec2 a_texCoord;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
          );
const std::string fragmentShader =
STRINGIFY(
          uniform sampler2D u_tex;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              vec3 l = normalize(vec3(100.0, -100.0, 100.0) - v_position);
              vec4 diffuse = vec4(0.2, 0.3, 1.0, 1.0) * (max(dot(v_normal, l), 0.0));
              vec4 ambient = vec4(0.1, 0.1, 0.3, 1.0);
              gl_FragColor = clamp(diffuse + ambient, 0.0, 1.0);
          }
          );

ShallowWater::ShallowWater(vec3 size, int segments) {
    this->size = size;
    this->segments = segments;
    
    for (int i = 0; i <= segments; i++) {
        h.push_back(i < segments/2 ? 1 : 0.5);
        uh.push_back(i < segments/2 ? 1 : 0.5);
        mid_h.push_back(i < segments/2 ? 1 : 0.5);
        mid_uh.push_back(i < segments/2 ? 1 : 0.5);
    }
    
    shared_ptr<Program> program = shared_ptr<Program>(new Program());
    program->buildProgram(vertexShader, fragmentShader);
    setProgram(program);
    
    shared_ptr<Cube> cube = shared_ptr<Cube>(new Cube(size.x, size.y, size.z, segments));
    setGeometry(cube);
    
    updateGeometry();
}

vec3 ShallowWater::getSize() {
    return size;
}

int ShallowWater::getSegments() {
    return segments;
}

void ShallowWater::update(float dt) {
    float sim_step = 0.002;
    int divisions = dt / sim_step;
    for (int i = 0; i < divisions; i++) {
        waterUpdate(sim_step);
    }
    updateGeometry();
}

void ShallowWater::waterUpdate(float dt) {
    const float gravity = 2.0;
    float dx = size.x / segments;
    const float damp = 0.1;
    
    // Update midpoints
    for (int i = 0; i < segments; i++) {
        mid_h[i] = (h[i] + h[i + 1]) / 2 - (dt / 2.0) * (uh[i] + uh[i + 1]) / dx;
        mid_uh[i] = (uh[i] + uh[i + 1]) / 2 - (dt/2.0)*(uh[i + 1] * uh[i + 1]/h[i + 1] + 0.5 * gravity * h[i + 1] * h[i + 1] - uh[i] * uh[i]/h[i] - 0.5 * gravity * h[i]*h[i])/dx;
    }
    
    // Update the positions
    for (int i = 0; i < segments - 1; i++) {
        h[i + 1] -= dt * (mid_uh[i + 1] - mid_uh[i])/dx;
        uh[i + 1] -= dt * (damp * uh[i + 1] + mid_uh[i + 1] * mid_uh[i + 1]/mid_h[i + 1] + 0.5 * gravity * mid_h[i + 1] * mid_h[i + 1] - mid_uh[i]*mid_uh[i]/mid_h[i] - 0.5 * gravity * mid_h[i]*mid_h[i])/dx;
    }
    
    // Boundary conditions
    h[0] = h[1];
    h[segments] = h[segments - 1];
    uh[0] = -uh[1];
    uh[segments] = -uh[segments - 1];
}

void ShallowWater::updateGeometry() {
    shared_ptr<Geometry> geo = getGeometry();
    float dx = size.x / segments;
    
    // Update the top of the cube
    for (int i = 0; i <= segments; i++) {
        for (int j = 0; j <= 1; j++) {
            int index = i*2 + j; //  + (2*(segments + 1)*2 + 2*2*2);
            
            vec3 normal, position;
            vec2 texCoord;
            geo->getVertex(index, position, normal, texCoord);
            
            // Update the position
            position.z = h[i];
            
            if (i < segments) {
                normal = vec3(dx, 0.0, h[i+1]-h[i]).normalize().cross(vec3(0.0, 1.0, 0.0));
            } else {
                normal = vec3(0.0, 1.0, 0.0).cross(vec3(-dx, 0.0, h[i-1] - h[i]).normalize());
            }
            
            geo->setVertex(index, position, normal, texCoord);
        }
    }
    
    // Update the front and back
    for (int i = 0; i <= segments; i++) {
        for (int j = 1; j <= 1; j++) {
            int index = i*2 + j + (2*(segments + 1)*2 + 2*2*2);
            vec3 normal, position;
            vec2 texCoord;
            
            geo->getVertex(index, position, normal, texCoord);
            position.z = h[i];
            geo->setVertex(index, position, normal, texCoord);
        }
    }
    
    for (int i = 0; i <= segments; i++) {
        for (int j = 1; j <= 1; j++) {
            int index = i*2 + j + (2*(segments + 1)*2 + 2*2*2 + 2*(segments + 1));
            vec3 normal, position;
            vec2 texCoord;
            
            geo->getVertex(index, position, normal, texCoord);
            position.z = h[i];
            geo->setVertex(index, position, normal, texCoord);
        }
    }
    
    // Update the left and right faces
    for (int i = 1; i <= 1; i++) {
        for (int j = 0; j <= 1; j++) {
            int index = i*2 + j + (2*(segments + 1)*2);
            vec3 normal, position;
            vec2 texCoord;
            
            geo->getVertex(index, position, normal, texCoord);
            position.z = h[0];
            geo->setVertex(index, position, normal, texCoord);
        }
    }
    
    for (int i = 1; i <= 1; i++) {
        for (int j = 0; j <= 1; j++) {
            int index = i*2 + j + (2*(segments + 1)*2 + 2*2);
            vec3 normal, position;
            vec2 texCoord;
            
            geo->getVertex(index, position, normal, texCoord);
            position.z = h[segments];
            geo->setVertex(index, position, normal, texCoord);
        }
    }
    
    geo->flushVertexChanges();
}



