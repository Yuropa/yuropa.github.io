
#ifndef MAT4_H
#define MAT4_H

#include <cmath>
#include <iostream>
#include <SDL2/SDL_opengl.h>
#include "vec3.h"

class mat4;

inline mat4 operator*(const float s, const mat4 &m);
inline mat4 operator*(const mat4 &mat, const float scale);

class mat4 {
public:
    float m00, m01, m02, m03;
    float m10, m11, m12, m13;
    float m20, m21, m22, m23;
    float m30, m31, m32, m33;
    
    inline mat4(float m00, float m01, float m02, float m03,
                float m10, float m11, float m12, float m13,
                float m20, float m21, float m22, float m23,
                float m30, float m31, float m32, float m33) {
        this->m00 = m00; this->m01 = m01; this->m02 = m02; this->m03 = m03;
        this->m10 = m10; this->m11 = m11; this->m12 = m12; this->m13 = m13;
        this->m20 = m20; this->m21 = m21; this->m22 = m22; this->m23 = m23;
        this->m30 = m30; this->m31 = m31; this->m32 = m32; this->m33 = m33;
    }
    
    inline mat4() : mat4(1, 0, 0, 0,
                         0, 1, 0, 0,
                         0, 0, 1, 0,
                         0, 0, 0, 1) {}
    
    static inline mat4 identity() {
        return mat4(1, 0, 0, 0,
                    0, 1, 0, 0,
                    0, 0, 1, 0,
                    0, 0, 0, 1);
    }
    
    static inline mat4 scale(const vec3 &s) {
        return scale(s.x, s.y, s.z);
    }
    
    static inline mat4 scale(float x, float y, float z) {
        return mat4(x, 0, 0, 0,
                    0, y, 0, 0,
                    0, 0, z, 0,
                    0, 0, 0, 1);
    }
    
    static inline mat4 translation(const vec3 &tranlsation) {
        return translation(tranlsation.x, tranlsation.y, tranlsation.z);
    }
    
    static inline mat4 translation(float x, float y, float z) {
        return mat4(1, 0, 0, 0,
                    0, 1, 0, 0,
                    0, 0, 1, 0,
                    x, y, z, 1);
    }
    
    static inline mat4 xRotation(float radians) {
        float cos = cosf(radians);
        float sin = sinf(radians);
        
        return mat4(1.0f, 0.0f, 0.0f, 0.0f,
                    0.0f,  cos, sin,  0.0f,
                    0.0f, -sin, cos,  0.0f,
                    0.0f, 0.0f, 0.0f, 1.0f );
    }
    
    static inline mat4 yRotation(float radians) {
        float cos = cosf(radians);
        float sin = sinf(radians);
        
        return mat4( cos, 0.0f, -sin, 0.0f,
                    0.0f, 1.0f, 0.0f, 0.0f,
                     sin, 0.0f,  cos, 0.0f,
                    0.0f, 0.0f, 0.0f, 1.0f );
    }
    
    static inline mat4 zRotation(float radians) {
        float cos = cosf(radians);
        float sin = sinf(radians);
        
        return mat4( cos,  sin, 0.0f, 0.0f,
                    -sin,  cos, 0.0f, 0.0f,
                    0.0f, 0.0f, 1.0f, 0.0f,
                    0.0f, 0.0f, 0.0f, 1.0f );
    }
    
    inline mat4 operator*(const mat4 &m) const {
        // [ 0 4  8 12 ]   [ 0 4  8 12 ]
        // [ 1 5  9 13 ] x [ 1 5  9 13 ]
        // [ 2 6 10 14 ]   [ 2 6 10 14 ]
        // [ 3 7 11 15 ]   [ 3 7 11 15 ]
        
        return mat4(m00*m.m00 + m01*m.m10 + m02*m.m20 + m03*m.m30,
                    m00*m.m01 + m01*m.m11 + m02*m.m21 + m03*m.m31,
                    m00*m.m02 + m01*m.m12 + m02*m.m22 + m03*m.m32,
                    m00*m.m03 + m01*m.m13 + m02*m.m23 + m03*m.m33,
                    
                    m10*m.m00 + m11*m.m10 + m12*m.m20 + m13*m.m30,
                    m10*m.m01 + m11*m.m11 + m12*m.m21 + m13*m.m31,
                    m10*m.m02 + m11*m.m12 + m12*m.m22 + m13*m.m32,
                    m10*m.m03 + m11*m.m13 + m12*m.m23 + m13*m.m33,
                    
                    m20*m.m00 + m21*m.m10 + m22*m.m20 + m23*m.m30,
                    m20*m.m01 + m21*m.m11 + m22*m.m21 + m23*m.m31,
                    m20*m.m02 + m21*m.m12 + m22*m.m22 + m23*m.m32,
                    m20*m.m03 + m21*m.m13 + m22*m.m23 + m23*m.m33,
                    
                    m30*m.m00 + m31*m.m10 + m32*m.m20 + m33*m.m30,
                    m30*m.m01 + m31*m.m11 + m32*m.m21 + m33*m.m31,
                    m30*m.m02 + m31*m.m12 + m32*m.m22 + m33*m.m32,
                    m30*m.m03 + m31*m.m13 + m32*m.m23 + m33*m.m33);
    }
    
    inline vec4 operator*(const vec4 &v) const {
        return vec4(m00*v.x + m01*v.y + m02*v.z + m03*v.w,
                    m10*v.x + m11*v.y + m12*v.z + m13*v.w,
                    m20*v.x + m21*v.y + m22*v.z + m23*v.w,
                    m30*v.x + m31*v.y + m32*v.z + m33*v.w);
    }
    
    inline mat4 operator+(const mat4 &m) const {
        return mat4(m00+m.m00, m01+m.m01, m02+m.m02, m03+m.m03,
                    m10+m.m10, m11+m.m11, m12+m.m12, m13+m.m13,
                    m20+m.m20, m21+m.m21, m22+m.m22, m23+m.m23,
                    m30+m.m30, m31+m.m31, m32+m.m32, m33+m.m33);
    }
    
    inline mat4 invert() const {
        // Implementation for the inverse was adapated from http://www.euclideanspace.com/maths/algebra/matrix/functions/inverse/fourD/index.htm
        // This is probably a more effient way to calculate the inverse, but this should work
        float determinant =
        m03*m12*m21*m30 - m02*m13*m21*m30 - m03*m11*m22*m30 + m01*m13*m22*m30+
        m02*m11*m23*m30 - m01*m12*m23*m30 - m03*m12*m20*m31 + m02*m13*m20*m31+
        m03*m10*m22*m31 - m00*m13*m22*m31 - m02*m10*m23*m31 + m00*m12*m23*m31+
        m03*m11*m20*m32 - m01*m13*m20*m32 - m03*m10*m21*m32 + m00*m13*m21*m32+
        m01*m10*m23*m32 - m00*m11*m23*m32 - m02*m11*m20*m33 + m01*m12*m20*m33+
        m02*m10*m21*m33 - m00*m12*m21*m33 - m01*m10*m22*m33 + m00*m11*m22*m33;
        if (determinant == 0.0) {
            return mat4::identity();
        }
        
        mat4 m = mat4(
        m12*m23*m31 - m13*m22*m31 + m13*m21*m32 - m11*m23*m32 - m12*m21*m33 + m11*m22*m33,
        m03*m22*m31 - m02*m23*m31 - m03*m21*m32 + m01*m23*m32 + m02*m21*m33 - m01*m22*m33,
        m02*m13*m31 - m03*m12*m31 + m03*m11*m32 - m01*m13*m32 - m02*m11*m33 + m01*m12*m33,
        m03*m12*m21 - m02*m13*m21 - m03*m11*m22 + m01*m13*m22 + m02*m11*m23 - m01*m12*m23,
        m13*m22*m30 - m12*m23*m30 - m13*m20*m32 + m10*m23*m32 + m12*m20*m33 - m10*m22*m33,
        m02*m23*m30 - m03*m22*m30 + m03*m20*m32 - m00*m23*m32 - m02*m20*m33 + m00*m22*m33,
        m03*m12*m30 - m02*m13*m30 - m03*m10*m32 + m00*m13*m32 + m02*m10*m33 - m00*m12*m33,
        m02*m13*m20 - m03*m12*m20 + m03*m10*m22 - m00*m13*m22 - m02*m10*m23 + m00*m12*m23,
        m11*m23*m30 - m13*m21*m30 + m13*m20*m31 - m10*m23*m31 - m11*m20*m33 + m10*m21*m33,
        m03*m21*m30 - m01*m23*m30 - m03*m20*m31 + m00*m23*m31 + m01*m20*m33 - m00*m21*m33,
        m01*m13*m30 - m03*m11*m30 + m03*m10*m31 - m00*m13*m31 - m01*m10*m33 + m00*m11*m33,
        m03*m11*m20 - m01*m13*m20 - m03*m10*m21 + m00*m13*m21 + m01*m10*m23 - m00*m11*m23,
        m12*m21*m30 - m11*m22*m30 - m12*m20*m31 + m10*m22*m31 + m11*m20*m32 - m10*m21*m32,
        m01*m22*m30 - m02*m21*m30 + m02*m20*m31 - m00*m22*m31 - m01*m20*m32 + m00*m21*m32,
        m02*m11*m30 - m01*m12*m30 - m02*m10*m31 + m00*m12*m31 + m01*m10*m32 - m00*m11*m32,
        m01*m12*m20 - m02*m11*m20 + m02*m10*m21 - m00*m12*m21 - m01*m10*m22 + m00*m11*m22);
        return m * (1.0 / determinant);
    }
    
    inline mat4 transpose() const {
        return mat4(m00, m10, m20, m30,
                    m02, m11, m21, m31,
                    m03, m12, m22, m32,
                    m03, m13, m23, m33);
    }
    
    inline void loadToUniform(GLint uniform) const {
        GLfloat matrix[] = {m00, m01, m02, m03,
            m10, m11, m12, m13,
            m20, m21, m22, m23,
            m30, m31, m32, m33};
        glUniformMatrix4fv(uniform, 1, false, matrix);
    }
};

inline mat4 operator*(const float s, const mat4 &m) {
    return mat4(s*m.m00, s*m.m01, s*m.m02, s*m.m03,
                s*m.m10, s*m.m11, s*m.m12, s*m.m13,
                s*m.m20, s*m.m21, s*m.m22, s*m.m23,
                s*m.m30, s*m.m31, s*m.m32, s*m.m33);
}

inline mat4 operator*(const mat4 &mat, const float scale) {
    return scale * mat;
}

inline std::ostream & operator<<(std::ostream & os, const mat4 & m)
{
    os << m.m00 << " " << m.m01 << " " << m.m02 << " " << m.m03 << std::endl;
    os << m.m10 << " " << m.m11 << " " << m.m12 << " " << m.m13 << std::endl;
    os << m.m20 << " " << m.m21 << " " << m.m22 << " " << m.m23 << std::endl;
    os << m.m30 << " " << m.m31 << " " << m.m32 << " " << m.m33 << std::endl;
    return os;
}

#endif