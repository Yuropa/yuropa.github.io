
#ifndef Geometry_hpp
#define Geometry_hpp

#include <vector>
#include <stdio.h>
#include "Math.h"
#include "OpenGL.h"

class Geometry {
protected:
    std::vector<GLfloat> data;
    std::vector<GLuint>  indicies;
    bool prepared;
#ifdef __APPLE__
    GLuint vao;
#endif
    GLuint dataBuf;
    GLuint indexBuf;
public:
    Geometry();
    ~Geometry();
    Geometry(Geometry &geo);
    
    void addVertex(vec3 position, vec3 normal, vec2 textCoord);
    void addIndex(int index);
    // This only needs to be called once, after which index data cannot be modified
    // Vertex data can be modified using the methods below
    void prepareForRendering();
    
    // Allows the vertex data to be read and changed. Changes will not take effect until
    // flushVertexChanges() is called, allowing changes to be batched
    void setVertex(int i, vec3  position, vec3  normal, vec2  textCoord);
    void getVertex(int i, vec3 &position, vec3 &normal, vec2 &textCoord);
    void flushVertexChanges();
    int numberOfVerticies();
    
    void bind();
    void unbind();
    void draw();
    void drawInstancedCount(GLsizei count);
};

#endif /* Geometry_hpp */
