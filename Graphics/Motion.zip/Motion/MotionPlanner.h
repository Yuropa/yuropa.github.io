
#ifndef MotionPlanner_hpp
#define MotionPlanner_hpp

#include "Node.h"

class MotionObstacle;
class MotionObstacle : public enable_shared_from_this<MotionObstacle> {
public:
    virtual vec2 getPosition();
    virtual shared_ptr<Geometry> getGeometry();
    virtual bool containsPoint(vec2 point);
    virtual bool intersectLineSegment(vec2 start, vec2 end);
    virtual void addExtent(float radius);
};

class CircleObstacle : public MotionObstacle {
    float radius;
    vec2 position;
public:
    CircleObstacle(vec2 position, float radius);
    
    float getRadius();
    virtual vec2 getPosition();
    
    virtual shared_ptr<Geometry> getGeometry();
    virtual bool containsPoint(vec2 point);
    virtual bool intersectLineSegment(vec2 start, vec2 end);
    virtual void addExtent(float radius);
};

class MotionPlanner : public Node {
    float width, height;
    shared_ptr<Node> startIndicator, endIndicator;
    vector<shared_ptr<Node>> waypoints;
    
    class LineSegment {
    public:
        vec2 start, end;
        LineSegment(vec2 start, vec2 end) {
            this->start = start;
            this->end = end;
        }
    };
    
    vector<shared_ptr<Node>> connections;
    shared_ptr<Texture> connectionTexture;
    shared_ptr<Texture> selectedConnectionTexture;
    
    vector<shared_ptr<MotionObstacle>> obsticals;
    bool showDebug;
    bool routePlanned;
    
    shared_ptr<Program> obstalProgram;
    
    shared_ptr<Texture> waypointTexture;
    shared_ptr<Program> waypointProgram;
    shared_ptr<Geometry> waypointGeometry;
    shared_ptr<Node> agent;
    int targetWaypoint;
    vector<vec2> targetWaypoints;
public:
    MotionPlanner(float width, float height);
    
    float getHeight();
    float getWidth();
    
    void setStartPosition(vec2 pos);
    vec2 getStartPosition();
    void setEndPosition(vec2 pos);
    vec2 getEndPosition();
    void addObstacle(shared_ptr<MotionObstacle> obstacle);
    
    void generateRoute();
    
    void setEnableDebug(bool flag);
    bool enableDebug();
    
    virtual void update(float dt);
    virtual void draw(const mat4 &projectionTransform);
};

#endif /* MotionPlanner_hpp */
