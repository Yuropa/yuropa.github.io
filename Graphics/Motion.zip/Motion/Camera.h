
#ifndef Camera_hpp
#define Camera_hpp

#include "Node.h"

class Camera : public Node {
    float fov, aspect, near, far;
    float scale;
    mat4 projection;
    mat4 view;
    bool needsProjectionUpdate;
    bool needsViewUpdate;
    
    virtual void setNeedsWorldTransformUpdate();
public:
    Camera(float aspect, float near, float far);
    ~Camera();
    
    void setScale(float scale);
    float getScale();
    void setAspect(float aspect);
    float getAspect();
    void setNear(float near);
    float getNear();
    void setFar(float far);
    float getFar();
    
    mat4 viewMatrix();
    mat4 projectionMatrix();
};

#endif /* Camera_hpp */
