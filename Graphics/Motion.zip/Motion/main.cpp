
#include <iostream>
#include <sys/time.h>
#include "App.h"

int width = 640;
int height = 480;

timeval currentTime() {
    timeval currentTime;
    gettimeofday(&currentTime, NULL);
    return currentTime;
}

// t1 is assumed to come after t2, so t1 >= t2, otherwise the result will be negative
long millisBetween(timeval t1, timeval t2) {
    time_t secs       = t1.tv_sec  - t2.tv_sec;
    suseconds_t usecs = t1.tv_usec - t2.tv_usec;
    
    return secs * 1000 + usecs / 1000;
}

int main(int, char**){
    srand((unsigned int)time(0));
    
	// SDL initialization
	if (SDL_Init(SDL_INIT_VIDEO) != 0){
		std::cout << "SDL_Init Error: " << SDL_GetError() << std::endl;
		return 1;
	}
    
    // Set OpenGL properties
    SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);
    SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);
    SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);
    SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 8);
    
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 32);
    
	// Create a window
	SDL_Window* win = SDL_CreateWindow("Particle System", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, width, height, SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);
	if (win == nullptr) {
		std::cout << "SDL_CreateWindow Error: " << SDL_GetError() << std::endl;
		SDL_Quit();
		return 1;
	}

	// Setup the OpenGL state
    SDL_GLContext glContext = SDL_GL_CreateContext(win);
    if(glContext == nullptr) {
        SDL_DestroyWindow(win);
        std::cout << "SDL_GL_CreateContext Error: " << SDL_GetError() << std::endl;
        SDL_Quit();
        return 1;
    }
    
    App app = App();
    app.setup();
    SDL_GL_GetDrawableSize(win, &width, &height);
    app.resizeTo(width, height);
    
    timeval lastTime = currentTime();
    
	// Main loop that calls draw() with the renderer and polls events
	// (primarily to make windowing systems happy to support quitting)
	SDL_Event e;
	bool quit = false;
    bool printFPS = false;
	while(!quit) {
		// Poll all events
		while (SDL_PollEvent(&e)) {
            switch (e.type) {
                case SDL_QUIT:
                    quit = true;
                    break;
                case SDL_WINDOWEVENT:
                    if (e.window.event == SDL_WINDOWEVENT_SIZE_CHANGED) {
                        SDL_GL_GetDrawableSize(win, &width, &height);
                        app.resizeTo(width, height);
                    }
                    break;
                case SDL_KEYDOWN:
                    if (e.key.keysym.sym == SDLK_ESCAPE) {
                        quit = true;
                    } else if (e.key.keysym.sym == SDLK_BACKQUOTE) {
                        printFPS = true;
                    } else {
                        app.handleKeyPress(e.key.keysym.sym, e.key.repeat);
                    }
                    break;
                case SDL_KEYUP:
                    app.handleKeyRelease(e.key.keysym.sym);
                    break;
                case SDL_MOUSEBUTTONDOWN:
                    app.handleMouseMove(0, 0, e.button.button);
                    break;
                case SDL_MOUSEMOTION:
                    app.handleMouseMove(e.motion.xrel, e.motion.yrel, e.motion.state);
                    break;
                case SDL_USEREVENT:
                    app.handleUserEvent(e.user.data1);
                default:
                    break;
            }
		}
        
        // Get the new time stamp
        timeval newTime = currentTime();
        long duration = millisBetween(newTime, lastTime);
        lastTime = newTime;
        
        if (printFPS) {
            std::cout << "FPS: " << 1.0 / (duration / 1000.0) << std::endl;
            printFPS = false;
        }
        
        app.update((float)duration / 1000.0);
		app.draw();

		// Flush to the screen
        SDL_GL_SwapWindow(win);
	}
    
	SDL_DestroyWindow(win);
	SDL_Quit();
	return 0;
}
