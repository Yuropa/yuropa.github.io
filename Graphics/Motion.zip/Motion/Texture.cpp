
#include <SDL2_image/SDL_image.h>
#include "Texture.h"

Texture::Texture(int width, int height, void *data) {
    load(width, height, data);
}

void Texture::load(int width, int height, void *data) {
    this->width = width;
    this->height = height;
    
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_BGRA, GL_UNSIGNED_BYTE, data);
}

Texture::Texture(std::string fileName) {
    SDL_Surface *surface = IMG_Load(fileName.c_str());
    if (!surface) {
        std::cout << "Unable to load image " << fileName << " SDL_image Error: " << IMG_GetError() << std::endl;
        this->width = 0;
        this->height = 0;
        this->tex = 0;
        return;
    }
    
    SDL_Surface *RGBSurface = SDL_ConvertSurfaceFormat(surface, SDL_PIXELFORMAT_RGBA8888, 0);
    if (!RGBSurface) {
        std::cout << "Unable to convert image to RGBA8888 SDL_image Error: " << IMG_GetError() << std::endl;
        this->width = 0;
        this->height = 0;
        this->tex = 0;
        return;
    }
    
    load(surface->w, surface->h, surface->pixels);
    
    SDL_FreeSurface(RGBSurface);
    SDL_FreeSurface(surface);
}

Texture::~Texture() {
    glDeleteTextures(1, &tex);
}

int Texture::getWidth() {
    return width;
}
int Texture::getHeight() {
    return height;
}

void Texture::bind() {
    glBindTexture(GL_TEXTURE_2D, tex);
}
