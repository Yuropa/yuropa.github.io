
#ifndef Plane_hpp
#define Plane_hpp

#include "Geometry.h"

class Plane : public Geometry {
    float height, depth;
    int heightSegments;
    int depthSegments;
    
    static const int positionAttribute = 1;
    static const int normalAttribute = 2;
public:
    Plane(float height, float depth, int heightSegments = 1, int depthSegments = 1);
    
    float getHeight();
    float getDepth();
    int getHeightSegments();
    int getDepthSegments();
};

#endif /* Plane_hpp */
