
#include <algorithm>
#include <map>
#include <queue>
#include "MotionPlanner.h"
#include "Plane.h"

#define STRINGIFY(x) #x
const string waypointVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec2 a_texCoord;
          
          varying vec2 v_uv;
          
          void main() {
              v_uv = a_texCoord;
              gl_Position = u_projection * u_modelView * vec4(a_position, 1.0);
          }
          );
const string waypointFragmentShader =
STRINGIFY(
          uniform sampler2D u_tex;
          
          varying vec2 v_uv;
          void main() {
              gl_FragColor = texture2D(u_tex, v_uv);
          }
          );

const string obstacleVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
          );
const string obstacleFragmentShader =
STRINGIFY(
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              vec3 l = normalize(vec3(100.0, 0.0, 100.0) - v_position);
              vec4 color = vec4(0.2, 1.0, 0.6, 1.0) * (0.8 * max(dot(v_normal, l), 0.0) + 0.2);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
          );

#define STRINGIFY(x) #x
const string agentVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
          );
const string agentFragmentShader =
STRINGIFY(
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              vec3 l = normalize(vec3(100.0, 0.0, 100.0) - v_position);
              vec4 color = vec4(1.0, 0.2, 0.6, 1.0) * (0.8 * max(dot(v_normal, l), 0.0) + 0.2);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
          );


shared_ptr<Geometry> MotionObstacle::getGeometry() {
    return nullptr;
}
vec2 MotionObstacle::getPosition() {
    return vec2(0.0);
}
bool MotionObstacle::containsPoint(vec2 point) {
    return false;
}
bool MotionObstacle::intersectLineSegment(vec2 start, vec2 end) {
    return false;
}
void MotionObstacle::addExtent(float radius) {
    
}



CircleObstacle::CircleObstacle(vec2 position, float radius) {
    this->position = position;
    this->radius = radius;
}

float CircleObstacle::getRadius() {
    return radius;
}
vec2 CircleObstacle::getPosition() {
    return position;
}

shared_ptr<Geometry> CircleObstacle::getGeometry() {
    return shared_ptr<Sphere>(new Sphere(radius));
}
bool CircleObstacle::containsPoint(vec2 point) {
    return (point - position).length() < radius;
}
bool CircleObstacle::intersectLineSegment(vec2 start, vec2 end) {
    
    vec2 p = start - getPosition();
    vec2 v = end - start;
    
    float a = v.dot(v);
    float b = 2*p.dot(v);
    float c = p.dot(p) - getRadius() * getRadius();\
    
    float discriminant = b*b - 4*a*c;
    if (discriminant < 0.0) {
        // No solutions
        return false;
    }
    
    // Solve for the two times using the quadratic formula
    float solution1 = (-b + sqrt(discriminant))/(2 * a);
    float solution2 = (-b - sqrt(discriminant))/(2 * a);
    
    if (solution1 >= 0.0 && solution1 <= 1.0) {
        return true;
    }
    if (solution2 >= 0.0 && solution2 <= 1.0) {
        return true;
    }
    
    return false;
}
void CircleObstacle::addExtent(float radius) {
    this->radius += radius;
}

#define PointSize 0.5

MotionPlanner::MotionPlanner(float width, float height) {
    this->width = width;
    this->height = height;
    routePlanned = false;
    
    obstalProgram = shared_ptr<Program>(new Program());
    obstalProgram->bindAttribute(PositionAttributeLocation, PositionAttribute);
    obstalProgram->bindAttribute(NormalAttributeLocation,   NormalAttribute);
    obstalProgram->buildProgram(obstacleVertexShader, obstacleFragmentShader);
    
    waypointProgram = shared_ptr<Program>(new Program());
    waypointProgram->bindAttribute(PositionAttributeLocation, PositionAttribute);
    waypointProgram->bindAttribute(TexCoordAttributeLocation, TexCoordAttribute);
    waypointProgram->buildProgram(waypointVertexShader, waypointFragmentShader);
    
    selectedConnectionTexture = shared_ptr<Texture>(new Texture("Textures/ConnectionUsed.png"));
    connectionTexture = shared_ptr<Texture>(new Texture("Textures/Connection.png"));
    waypointTexture = shared_ptr<Texture>(new Texture("Textures/Waypoint.png"));
    waypointGeometry = shared_ptr<Geometry>(new Plane(PointSize, PointSize));
    
    setEnableDebug(false);
}

void MotionPlanner::setStartPosition(vec2 pos) {
    vec3 position = vec3(pos.x, pos.y, 0.0);
    if (!startIndicator) {
        startIndicator = shared_ptr<Node>(new Node());
        startIndicator->setProgram(waypointProgram);
        startIndicator->setTexture(shared_ptr<Texture>(new Texture("Textures/Start.png")));
        startIndicator->setGeometry(waypointGeometry);
    }
    startIndicator->translateTo(position);
}
vec2 MotionPlanner::getStartPosition() {
    vec3 position = startIndicator->getPosition();
    return vec2(position.x, position.y);
}
void MotionPlanner::setEndPosition(vec2 pos) {
    vec3 position = vec3(pos.x, pos.y, 0.0);
    if (!endIndicator) {
        endIndicator = shared_ptr<Node>(new Node());
        endIndicator->setProgram(waypointProgram);
        endIndicator->setTexture(shared_ptr<Texture>(new Texture("Textures/End.png")));
        endIndicator->setGeometry(waypointGeometry);
    }
    endIndicator->translateTo(position);
}
vec2 MotionPlanner::getEndPosition() {
    vec3 position = endIndicator->getPosition();
    return vec2(position.x, position.y);
}

float randomFloat() {
    return (float)rand() / (float)RAND_MAX;
}

struct PathNode {
    int node;
    vec2 position;
    struct PathNode *parent;
    float cost;
    float heristic;
    float costToNode(PathNode *node) {
        return position.distanceTo(node->position);
    }
};

map<int, PathNode> nodes;
struct _PathNodeCompare {
    bool operator() (int &i, int &j) {
        return nodes[i].cost < nodes[j].cost;
    }
} PathNodeCompare;

void MotionPlanner::generateRoute() {
    for (int i = 0; i < obsticals.size(); i++) {
        obsticals[i]->addExtent(PointSize/2.0);
    }
    
    waypoints.clear();
    for (int i = 0; i < width/8; i++) {
        for (int j = 0; j < height/8; j++) {
            bool validPoint = true;
            vec2 point = vec2(randomFloat() * width - width / 2.0, randomFloat() * height - height / 2.0);
            
            for (int k = 0; k < obsticals.size(); k++) {
                if (obsticals[k]->containsPoint(point)) {
                    validPoint = false;
                    break;
                }
            }
            
            if (validPoint) {
                shared_ptr<Node> waypoint = shared_ptr<Node>(new Node());
                waypoint->translateTo(vec3(point.x, point.y, 0.0));
                waypoint->setProgram(waypointProgram);
                waypoint->setTexture(waypointTexture);
                waypoint->setGeometry(waypointGeometry);
                waypoint->setEnabled(showDebug);
                waypoints.push_back(waypoint);
            }
        }
    }
    
    map<int, vector<int>*> connections;
    nodes.clear();
    
    for (int i = -1; i < (int)waypoints.size(); i++) {
        for (int j = i + 1; j < waypoints.size() + 1; j++) {
            vec3 startPos;
            if (i == -1) {
                startPos = vec3(getStartPosition().x, getStartPosition().y, 0.0);
            } else {
                startPos = waypoints[i]->getPosition();
            }
            vec3 endPos;
            if (j == waypoints.size()) {
                endPos = vec3(getEndPosition().x, getEndPosition().y, 0.0);
            } else {
                endPos = waypoints[j]->getPosition();
            }
            vec2 start = vec2(startPos.x, startPos.y);
            vec2 end = vec2(endPos.x, endPos.y);
            
            bool isValidConnection = true;
            
            for (int k = 0; k < obsticals.size(); k++) {
                if (obsticals[k]->intersectLineSegment(start, end)) {
                    isValidConnection = false;
                    break;
                }
            }
            
            if (isValidConnection) {
                if (connections.count(i) <= 0) {
                    connections[i] = new vector<int>();
                }
                connections[i]->push_back(j);
                
                if (connections.count(j) <= 0) {
                    connections[j] = new vector<int>();
                }
                connections[j]->push_back(i);
                
                // connections
                shared_ptr<Node> node = shared_ptr<Node>(new Node());
                vec2 dir = end - start;
                node->translateTo(vec3(start.x, start.y, 0.0) + 0.5 * vec3(dir.x, dir.y, 0.0));
                float length = dir.length() - PointSize;
                node->scaleTo(vec3(length/PointSize, 1.0/8.0, 1.0));
                node->rotateTo(vec3(0.0, 0.0, atan2(dir.y, dir.x)));
                node->setGeometry(waypointGeometry);
                node->setProgram(waypointProgram);
                node->setTexture(connectionTexture);
                node->setEnabled(showDebug);
                this->connections.push_back(node);
            }
        }
    }
    
    vector<int> queue;
    
    for (int i = 0; i < waypoints.size(); i++) {
        PathNode node;
        node.node = i;
        node.parent = NULL;
        node.cost = INFINITY;
        vec3 pos = waypoints[i]->getPosition();
        node.position = vec2(pos.x, pos.y);
        node.heristic = node.position.distanceTo(getEndPosition());
        nodes[i] = node;
    }
    
    // Add end point
    PathNode endNode;
    endNode.node = (int)waypoints.size();
    endNode.parent = NULL;
    endNode.cost = INFINITY;
    endNode.position = getEndPosition();
    endNode.heristic = 0.0;
    nodes[(int)waypoints.size()] = endNode;
    
    // Add start point
    PathNode startNode;
    startNode.node = -1;
    startNode.parent = NULL;
    startNode.cost = 0.0;
    startNode.position = getStartPosition();
    startNode.heristic = startNode.position.distanceTo(getEndPosition());
    nodes[-1] = startNode;
    
    for (map<int, PathNode>::iterator it = nodes.begin(); it != nodes.end(); it++) {
        queue.push_back(it->first);
    }
    
    // Perform A*
    while (queue.size() > 0) {
        vector<int>::iterator minElement = min_element(queue.begin(), queue.end(), PathNodeCompare);
        
        PathNode *node = &nodes[*minElement];
        queue.erase(minElement);
        if (node->node == waypoints.size()) {
            // Finished search
            break;
        }
        
        vector<int> *neighbors = connections[node->node];
        for (vector<int>::iterator it = neighbors->begin(); it != neighbors->end(); it++) {
            PathNode *neighbor = &nodes[*it];
            float alt = node->cost + node->costToNode(neighbor);
            if (alt < neighbor->cost) {
                neighbor->cost = alt;
                neighbor->parent = node;
            }
        }
    }
    
    // Have either completed path or no path at all
    bool foundCompletePath = false;
    PathNode *traverseNode = &nodes[(int)waypoints.size()];
    while (traverseNode->parent != NULL) {
        vec2 start = traverseNode->parent->position;
        vec2 end = traverseNode->position;
        
        // connections
        shared_ptr<Node> node = shared_ptr<Node>(new Node());
        vec2 dir = end - start;
        node->translateTo(vec3(start.x, start.y, 0.0) + 0.5 * vec3(dir.x, dir.y, 0.0));
        float length = dir.length() - PointSize;
        node->scaleTo(vec3(length/PointSize, 3.0/8.0, 1.0));
        node->rotateTo(vec3(0.0, 0.0, atan2(dir.y, dir.x)));
        node->setGeometry(waypointGeometry);
        node->setProgram(waypointProgram);
        node->setTexture(selectedConnectionTexture);
        node->setEnabled(showDebug);
        this->connections.push_back(node);
        
        if (traverseNode->parent->node == -1) {
            foundCompletePath = true;
        }
        targetWaypoints.push_back(end);
        traverseNode = traverseNode->parent;
    }
    
    if (!foundCompletePath) {
        targetWaypoints.clear();
    }
    
    targetWaypoint = 0;
    routePlanned = true;
}

void MotionPlanner::setEnableDebug(bool flag) {
    showDebug = flag;
    
    for (int i = 0; i < waypoints.size(); i++) {
        waypoints[i]->setEnabled(flag);
    }
    
    for (int i = 0; i < connections.size(); i++) {
        connections[i]->setEnabled(flag);
    }
}

bool MotionPlanner::enableDebug() {
    return showDebug;
}

void MotionPlanner::addObstacle(shared_ptr<MotionObstacle> obstacle) {
    obsticals.push_back(obstacle);
    
    shared_ptr<Node> node = shared_ptr<Node>(new Node());
    node->setGeometry(obstacle->getGeometry());
    vec2 pos = obstacle->getPosition();
    node->translateBy(vec3(pos.x, pos.y, 0.0));
    node->setProgram(obstalProgram);
    addChildNode(node);
}

void MotionPlanner::update(float dt) {
    if (routePlanned && targetWaypoints.size() > 0) {
        if (!agent) {
            agent = shared_ptr<Node>(new Node());
            vec2 position = getStartPosition();
            agent->translateTo(vec3(position.x, position.y, 0.0));
            
            shared_ptr<Program> agentProgram = shared_ptr<Program>(new Program());
            agentProgram->bindAttribute(PositionAttributeLocation, PositionAttribute);
            agentProgram->bindAttribute(NormalAttributeLocation,   NormalAttribute);
            agentProgram->buildProgram(agentVertexShader, agentFragmentShader);
            agent->setProgram(agentProgram);
            
            agent->setGeometry(shared_ptr<Geometry>(new Sphere(PointSize/2.0)));
            addChildNode(agent);
        }
        
        vec3 pos = agent->getPosition();
        vec2 position = vec2(pos.x, pos.y);
        if (position.distanceTo(getEndPosition()) < PointSize/8.0) {
            position = getEndPosition();
        } else {
            vec2 dir = position - *(targetWaypoints.rbegin() + targetWaypoint);
            position = position - 2.0 * dir.normalize() * dt;
        }
        
        if (targetWaypoint < targetWaypoints.size() - 1) {
            // There is another way point for us to move to
            bool intersection = false;
            for (int i = 0; i < obsticals.size(); i++) {
                if (obsticals[i]->intersectLineSegment(position, *(targetWaypoints.rbegin() + targetWaypoint + 1))) {
                    intersection = true;
                    break;
                }
            }
            
            if (!intersection) {
                targetWaypoint++;
            }
        }
        
        agent->translateTo(vec3(position.x, position.y, 0.0));
    }
}


void MotionPlanner::draw(const mat4 &projectionTransform) {
    
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ONE);
    
    startIndicator->draw(projectionTransform);
    endIndicator->draw(projectionTransform);
    for (int i = 0; i < waypoints.size(); i++) {
        waypoints[i]->draw(projectionTransform);
    }
    
    for (int i = 0; i < connections.size(); i++) {
        connections[i]->draw(projectionTransform);
    }
    
    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
    Node::draw(projectionTransform);
}
