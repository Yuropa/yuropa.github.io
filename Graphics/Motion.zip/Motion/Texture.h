
#ifndef Texture_hpp
#define Texture_hpp

#include <string>
#include <SDL2/SDL_opengl.h>
#include "Math.h"

class Texture;

class Texture : public std::enable_shared_from_this<Texture>  {
    int width, height;
    GLuint tex;
    
    void load(int width, int height, void *data);
public:
    Texture(int width, int height, void *data);
    Texture(std::string fileName);
    ~Texture();
    
    int getWidth();
    int getHeight();
    
    void bind();
};

#endif /* Texture_hpp */
