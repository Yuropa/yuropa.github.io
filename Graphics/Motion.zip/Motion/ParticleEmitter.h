
#ifndef ParticleEmitter_hpp
#define ParticleEmitter_hpp

#include "Node.h"
#include "GridSpacePartitioner.h"

float randomFloat();

typedef struct {
    GLfloat x, y, z;
    GLfloat red, green, blue, alpha;
    GLfloat diffuseAmount;
} Particle;

typedef struct {
    float lifetime;
    void *userData;
} ParticleData;

typedef struct {
    Particle p;
    float lifetime;
    vec3 velocity;
    void *userData;
} CompleteParticle;

class ParticleEmitter : public Node {
    vec3 initialVelocity;
    float particleLifetime;
    float emissionRate;
    vector<Particle> particles;
    vector<ParticleData> lifetime;
    vector<vec3> velocity;
    float radius;
    GLuint positionVBO;
    shared_ptr<Texture> whiteTexture;
    
    void generateParticle();
    
protected:
    GridSpacePartitioner<size_t> particlesGridSpace;
public:
    ParticleEmitter(float radius);
    ~ParticleEmitter();
    
    void setInitialVelocity(vec3 initialVelocity);
    vec3 getInitialVelocity();
    
    void setParticleLifetime(float particleLifetime);
    float getParticeLifetime();
    
    void setEmissionRate(float emissionRate);
    float getEmissionRate();
    
    std::vector<CompleteParticle>* particlesWithinDistance(size_t index, float distance);
    
    virtual void update(float dt);
    virtual void draw(const mat4 &projectionTransform);
    virtual void deleteUserData(void *data);
    virtual void updateParticle(size_t index, Particle &p, float &lifetime, vec3 &velocity, float dt, void * &userData);
    virtual void updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position, void * &userData);
};

#endif /* ParticleEmitter_hpp */
