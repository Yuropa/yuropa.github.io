
#ifndef Math_h
#define Math_h

#include "vec2.h"
#include "vec3.h"
#include "vec4.h"
#include "mat4.h"

#endif /* Math_h */
