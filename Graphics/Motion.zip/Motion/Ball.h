#ifndef Ball_hpp
#define Ball_hpp

#include "Node.h"

class Ball : public Node {
    float radius;
public:
    Ball(float radius);
    
    float getRadius();
    
};

#endif /* Ball_hpp */
