
#include "Cube.h"

Cube::Cube(float width, float height, float depth, int widthSegments, int heightSegments, int depthSegments) {
    this->width = width;
    this->height = height;
    this->depth = depth;
    this->widthSegments = widthSegments < 1 ? 1 : widthSegments;
    this->heightSegments = heightSegments < 1 ? 1 : heightSegments;
    this->depthSegments = depthSegments < 1 ? 1 : depthSegments;
    
    int currentIndex = 0;
    
    // Tesselate the front and back faces
    for (int i = 0; i <= widthSegments; i++) {
        vec3 normal = vec3(0.0, 0.0, 1.0);
        for (int j = 0; j <= heightSegments; j++) {
            vec3 pos = vec3((float)i / (float)widthSegments * width - width /2.0, (float)j / (float)heightSegments * height - height /2.0, depth/2.0);
            vec2 texCoord = vec2((float) i / (float)widthSegments, (float)j / (float)heightSegments);
            addVertex(pos, normal, texCoord);
        }
    }
    
    for (int i = 0; i <= widthSegments; i++) {
        vec3 normal = vec3(0.0, 0.0, -1.0);
        for (int j = 0; j <= heightSegments; j++) {
            vec3 pos = vec3((float)i / (float)widthSegments * width - width /2.0, (float)j / (float)heightSegments * height - height /2.0, -depth/2.0);
            vec2 texCoord = vec2((float) i / (float)widthSegments, (float)j / (float)heightSegments);
            addVertex(pos, normal, texCoord);
        }
    }
    
    for (int k = 0; k < 2; k++) {
        for (int i = 0; i < widthSegments; i++) {
            for (int j = 0; j < heightSegments; j++) {
                int i1 = currentIndex + i * (heightSegments + 1) + j;
                int i2 = currentIndex + i * (heightSegments + 1) + j + 1;
                int i3 = currentIndex + (i + 1) * (heightSegments + 1) + j;
                int i4 = currentIndex + (i + 1) * (heightSegments + 1) + j + 1;
                
                addIndex(i1);
                addIndex(i2);
                addIndex(i3);
                
                addIndex(i2);
                addIndex(i4);
                addIndex(i3);
            }
        }
        currentIndex += (widthSegments + 1) * (heightSegments + 1);
    }
    
    // Tesselate the left and right faces
    for (int i = 0; i <= depthSegments; i++) {
        vec3 normal = vec3(-1.0, 0.0, 0.0);
        for (int j = 0; j <= heightSegments; j++) {
            vec3 pos = vec3(-width /2.0, (float)j / (float)heightSegments * height - height /2.0, (float)i / (float)depthSegments *depth - depth / 2.0);
            vec2 texCoord = vec2((float) i / (float)depthSegments, (float)j / (float)heightSegments);
            addVertex(pos, normal, texCoord);
        }
    }
    
    for (int i = 0; i <= depthSegments; i++) {
        vec3 normal = vec3(1.0, 0.0, 1.0);
        for (int j = 0; j <= heightSegments; j++) {
            vec3 pos = vec3(width /2.0, (float)j / (float)heightSegments * height - height /2.0, (float)i / (float)depthSegments *depth - depth / 2.0);
            vec2 texCoord = vec2((float) i / (float)depthSegments, (float)j / (float)heightSegments);
            addVertex(pos, normal, texCoord);
        }
    }
    
    for (int k = 0; k < 2; k++) {
        for (int i = 0; i < depthSegments; i++) {
            for (int j = 0; j < heightSegments; j++) {
                int i1 = currentIndex + i * (heightSegments + 1) + j;
                int i2 = currentIndex + i * (heightSegments + 1) + j + 1;
                int i3 = currentIndex + (i + 1) * (heightSegments + 1) + j;
                int i4 = currentIndex + (i + 1) * (heightSegments + 1) + j + 1;
                
                addIndex(i1);
                addIndex(i2);
                addIndex(i3);
                
                addIndex(i2);
                addIndex(i4);
                addIndex(i3);
            }
        }
        currentIndex += (depthSegments + 1) * (heightSegments + 1);
    }
    
    // Tesselate the top and bottom faces
    for (int i = 0; i <= widthSegments; i++) {
        vec3 normal = vec3(0.0, -1.0, 0.0);
        for (int j = 0; j <= depthSegments; j++) {
            vec3 pos = vec3((float)i / (float)widthSegments * width - width /2.0, -height / 2.0, (float)j / (float)depthSegments * depth - depth/2.0);
            vec2 texCoord = vec2((float) i / (float)widthSegments, (float)j / (float)depthSegments);
            addVertex(pos, normal, texCoord);
        }
    }
    
    for (int i = 0; i <= widthSegments; i++) {
        vec3 normal = vec3(0.0, 1.0, 0.0);
        for (int j = 0; j <= depthSegments; j++) {
            vec3 pos = vec3((float)i / (float)widthSegments * width - width /2.0, height / 2.0, (float)j / (float)depthSegments * depth - depth/2.0);
            vec2 texCoord = vec2((float) i / (float)widthSegments, (float)j / (float)heightSegments);
            addVertex(pos, normal, texCoord);
        }
    }
    
    for (int k = 0; k < 2; k++) {
        for (int i = 0; i < widthSegments; i++) {
            for (int j = 0; j < depthSegments; j++) {
                int i1 = currentIndex + i * (depthSegments + 1) + j;
                int i2 = currentIndex + i * (depthSegments + 1) + j + 1;
                int i3 = currentIndex + (i + 1) * (depthSegments + 1) + j;
                int i4 = currentIndex + (i + 1) * (depthSegments + 1) + j + 1;
                
                addIndex(i1);
                addIndex(i2);
                addIndex(i3);
                
                addIndex(i2);
                addIndex(i4);
                addIndex(i3);
            }
        }
        currentIndex += (widthSegments + 1) * (depthSegments + 1);
    }
    
    prepareForRendering();
}

float Cube::getWidth() {
    return width;
}
float Cube::getHeight() {
    return height;
}
float Cube::getDepth() {
    return depth;
}
int Cube::getWidthSegments() {
    return widthSegments;
}
int Cube::getHeightSegments() {
    return heightSegments;
}
int Cube::getDepthSegments() {
    return depthSegments;
}
