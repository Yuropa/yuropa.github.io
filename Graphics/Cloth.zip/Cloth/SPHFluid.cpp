
#include "SPHFluid.h"

#define Particle_Radius 0.1
#define Pariticle_Attaction_Radius (Particle_Radius * 3.0)
#define Initial_Grid_Spacing (Particle_Radius * 4.0)
#define Resting_Density 1.0
#define K_Stiff 200.0


#define STRINGIFY(x) #x
const std::string vertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          attribute vec3 a_offset;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position + a_offset, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
          );
const std::string fragmentShader =
STRINGIFY(
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              vec3 l = normalize(vec3(0.0, 0.0, 100.0) - v_position);
              vec4 diffuse = vec4(0.2, 0.4, 0.8, 1.0) * (max(dot(v_normal, l), 0.0));
              vec4 ambient = vec4(0.1, 0.1, 0.2, 1.0);
              gl_FragColor = clamp(diffuse + ambient, 0.0, 1.0);
          }
          );

const GLint ParticlePosition      = TexCoordAttributeLocation + 1;

inline float randomFloat() {
    return (float)rand() / (float)RAND_MAX;
}

SPHFluid::SPHFluid(vec3 emitterPosition, vec3 boundSize) {
    this->emitterPosition = emitterPosition;
    this->boundSize = boundSize;
    
    translateTo(vec3(0.0, 0.0, boundSize.z/2.0));
    
    setGeometry(shared_ptr<Sphere>(new Sphere(Particle_Radius, 10, 10)));
    
    shared_ptr<Program> program = shared_ptr<Program>(new Program());
    program->bindAttribute(PositionAttributeLocation, PositionAttribute);
    program->bindAttribute(NormalAttributeLocation, NormalAttribute);
    
    program->bindAttribute(ParticlePosition, "a_offset");
    
    program->buildProgram(vertexShader, fragmentShader);
    setProgram(program);
    
    glGenBuffers(1, &positionVBO);
    GetGLError();
    
    for (int i = 1; i < boundSize.x / Initial_Grid_Spacing / 2; i++) {
        for (int j = 1; j < boundSize.y / Initial_Grid_Spacing - 1; j++) {
            for (int k = 1; k < boundSize.z / Initial_Grid_Spacing; k++) {
                vec3 pos = vec3(i, j, k) * vec3(Initial_Grid_Spacing) - boundSize/2;
                pos = pos + vec3(randomFloat() * 0.1 - 0.05, randomFloat() * 0.1 - 0.05, randomFloat() * 0.1 - 0.05);
                SPHRenderParticle p = {pos.x, pos.y, pos.z};
                SPHParticle data;
                data.position = pos;
                data.oldPos = pos;
                particles.push_back(data);
                renderParticles.push_back(p);
            }
        }
    }
}

SPHFluid::~SPHFluid() {
    glDeleteBuffers(1, &positionVBO);
}

vec3 SPHFluid::getEmitterPosition() {
    return emitterPosition;
}
vec3 SPHFluid::getBoundsSize() {
    return boundSize;
}

struct SPHPair {
    int index1;
    int index2;
    float q;
};

void SPHFluid::update(float dt) {
    int divisions = 1;
    for (int i = 0; i < divisions; i++) {
        particlesUpdate(dt / divisions);
    }
}

void SPHFluid::particlesUpdate(float dt) {
    for (int i = 0; i < particles.size(); i++) {
        SPHParticle *data = &particles[i];
        
        data->velocity = (data->position - data->oldPos) / dt;
        data->oldPos = data->position;
        data->velocity = data->velocity + vec3(0.0, 0.0, -2.0) * dt;
        data->position = data->position + data->velocity * dt;
        data->density = 0.0;
        
        vec3 containerCenter = getPosition();
        if (data->position.x < containerCenter.x - boundSize.x / 2.0 + Particle_Radius) {
            data->position.x = containerCenter.x - boundSize.x / 2.0 + Particle_Radius;
        }
        if (data->position.x > containerCenter.x + boundSize.x / 2.0 - Particle_Radius) {
            data->position.x = containerCenter.x + boundSize.x / 2.0 - Particle_Radius;
        }
        
        if (data->position.y < containerCenter.y - boundSize.y / 2.0 + Particle_Radius) {
            data->position.y = containerCenter.y - boundSize.y / 2.0 + Particle_Radius;
        }
        if (data->position.y > containerCenter.y + boundSize.y / 2.0 - Particle_Radius) {
            data->position.y = containerCenter.y + boundSize.y / 2.0 - Particle_Radius;
        }
        
        if (data->position.z < containerCenter.y - boundSize.z / 2.0 + Particle_Radius) {
            data->position.z = containerCenter.y - boundSize.z / 2.0 + Particle_Radius;
        }
        if (data->position.z > containerCenter.y + boundSize.z / 2.0 - Particle_Radius) {
            data->position.z = containerCenter.y + boundSize.z / 2.0 - Particle_Radius;
        }
        
        SPHRenderParticle p = {data->position.x, data->position.y, data->position.z};
        renderParticles[i] = p;
    }
    
    std::vector<SPHPair> pairs;
    for (int i = 0; i < particles.size(); i++) {
        for (int j = 0; j < i; j++) {
            SPHParticle p1 = particles[i];
            SPHParticle p2 = particles[j];
            
            if ((p1.position - p2.position).lengthSquared() < Pariticle_Attaction_Radius*Pariticle_Attaction_Radius) {
                SPHPair pair = {i, j, 0.0};
                pairs.push_back(pair);
            }
        }
    }
    
    for (int i = 0; i < pairs.size(); i++) {
        SPHPair *p = &pairs[i];
        
        SPHParticle *p1 = &particles[p->index1];
        SPHParticle *p2 = &particles[p->index2];
        
        p->q = 1 - p1->position.distanceTo(p2->position) / Pariticle_Attaction_Radius;
        float q2 = p->q * p->q;
        p1->density += q2;
        p2->density += q2;
    }
    
    for (int i = 0; i < particles.size(); i++) {
        SPHParticle *p = &particles[i];
        p->pressure = K_Stiff * (p->density - Resting_Density);
    }
    
    for (int i = 0; i < pairs.size(); i++) {
        SPHPair *p = &pairs[i];
        
        SPHParticle *p1 = &particles[p->index1];
        SPHParticle *p2 = &particles[p->index2];
        
        float pressure = p1->pressure + p2->pressure;
        float displace = (pressure * p->q) * dt * dt;
        vec3 normal = (p2->position - p1->position).normalize();
        
        p1->position = p1->position + displace * normal;
        p2->position = p2->position - displace * normal;
    }
}

void SPHFluid::draw(const mat4 &projectionTransform) {
    // Update load the data to the GPU
    shared_ptr<Geometry> geo = getGeometry();
    geo->bind();
    glBindBuffer(GL_ARRAY_BUFFER, positionVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(SPHRenderParticle) * renderParticles.size(), &renderParticles[0], GL_STREAM_DRAW);
    
    glEnableVertexAttribArray(ParticlePosition);
    glVertexAttribPointer(ParticlePosition, 3, GL_FLOAT, GL_FALSE, sizeof(SPHRenderParticle), 0);
    glVertexAttribDivisor(ParticlePosition, 1);
    
    updateWorldTransform();
    shared_ptr<Program> program = getProgram();
    program->useProgram();
    program->loadUniform(ProjectionUniform, projectionTransform);
    program->loadUniform(ModelViewMatrixUniform, worldTransform);
    program->loadUniform(NormalMatrixUniform, normalTransform);
    
    geo->drawInstancedCount((GLsizei)particles.size());
    geo->unbind();
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    GetGLError();
}
