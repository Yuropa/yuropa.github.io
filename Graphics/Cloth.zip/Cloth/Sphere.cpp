
#include <cmath>
#include <iostream>
#include "Sphere.h"

Sphere::Sphere(float r, int hs, int vs) {
    radius = r;
    horizontalSegments = hs;
    verticalSegments = vs;
    
    // Tessellation the sphere
    
    vec3 vTop = vec3(0, 0, radius);
    addVertex(vTop, vTop.normalize(), vec2(0.5, 0.0));
    
    int vertexCount = 2;
    for (int i = 1; i < verticalSegments; i++) {
        for (int j = 0; j < horizontalSegments; j++) {
            float phi   = 2 * M_PI * (float)j / (float) horizontalSegments;
            float theta =     M_PI * (float)i / (float) verticalSegments;
            vec3 v = vec3(radius * sinf(theta) * cosf(phi), radius * sinf(theta) * sinf(phi), radius * cosf(theta));
            vec3 n = v.normalize();
            
            vec2 texCoord = vec2((float)i / (float)verticalSegments, (float)j/ (float)horizontalSegments);
            addVertex(v, n, texCoord);
            vertexCount++;
        }
    }
    
    vec3 vBottom = vec3(0, 0, -radius);
    addVertex(vBottom, vBottom.normalize(), vec2(0.5, 1.0));
    
    // Top ring of triangles
    for (int i = 0; i < horizontalSegments; i++) {
        addIndex(0);
        if (i == 0) {
            addIndex(horizontalSegments);
            addIndex(1);
        } else {
            addIndex(i);
            addIndex(i + 1);
        }
    }
    
    for (int i = 0; i < verticalSegments - 2; i++) {
        for (int j = 0; j < horizontalSegments; j++) {
            int topRowIndex = i * horizontalSegments + 1 + j;
            int bottomRowIndex = (i + 1) * horizontalSegments + 1 + j;
            if (j == 0) {
                int lastTopRowIndex = (i + 1) * horizontalSegments;
                int lastBottomRowIndex = (i + 2) * horizontalSegments;
                
                addIndex(lastTopRowIndex);
                addIndex(lastBottomRowIndex);
                addIndex(topRowIndex);
                
                addIndex(topRowIndex);
                addIndex(lastBottomRowIndex);
                addIndex(bottomRowIndex);
            } else {
                addIndex(topRowIndex - 1);
                addIndex(bottomRowIndex - 1);
                addIndex(topRowIndex);
                
                addIndex(topRowIndex);
                addIndex(bottomRowIndex - 1);
                addIndex(bottomRowIndex);
            }
        }
    }
    
    // Bottom ring of triangles
    int lastIndex = vertexCount - 1;
    for (int i = 0; i < horizontalSegments; i++) {
        addIndex(lastIndex);
        if (i == 0) {
            addIndex(lastIndex - horizontalSegments);
            addIndex(lastIndex - 1);
        } else {
            addIndex(lastIndex - horizontalSegments + i);
            addIndex(lastIndex - horizontalSegments + i - 1);
        }
    }
    
    prepareForRendering();
}

float Sphere::getRadius() {
    return radius;
}
int Sphere::getHorizontalSegments() {
    return horizontalSegments;
}
int Sphere::getVerticalSegments() {
    return verticalSegments;
}
