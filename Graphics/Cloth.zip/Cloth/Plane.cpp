
#include "Plane.h"

Plane::Plane(float height, float depth, int heightSegments, int depthSegments) {
    this->height = height;
    this->depth = depth;
    this->heightSegments = heightSegments < 1 ? 1 : heightSegments;
    this->depthSegments = depthSegments < 1 ? 1 : depthSegments;
    
    int currentIndex = 0;
    
    // Tesselate the faces
    for (int i = 0; i <= depthSegments; i++) {
        vec3 normal = vec3(-1.0, 0.0, 0.0);
        for (int j = 0; j <= heightSegments; j++) {
            vec3 pos = vec3(0.0, (float)j / (float)heightSegments * height - height /2.0, (float)i / (float)depthSegments * depth - depth / 2.0);
            vec2 texCoord = vec2((float) i / (float)depthSegments, (float)j / (float)heightSegments);
            addVertex(pos, normal, texCoord);
        }
    }
    
    for (int i = 0; i < depthSegments; i++) {
        for (int j = 0; j < heightSegments; j++) {
            int i1 = currentIndex + i * (heightSegments + 1) + j;
            int i2 = currentIndex + i * (heightSegments + 1) + j + 1;
            int i3 = currentIndex + (i + 1) * (heightSegments + 1) + j;
            int i4 = currentIndex + (i + 1) * (heightSegments + 1) + j + 1;
            
            addIndex(i1);
            addIndex(i2);
            addIndex(i3);
            
            addIndex(i2);
            addIndex(i4);
            addIndex(i3);
        }
    }
    
    prepareForRendering();
}

float Plane::getHeight() {
    return height;
}
float Plane::getDepth() {
    return depth;
}
int Plane::getHeightSegments() {
    return heightSegments;
}
int Plane::getDepthSegments() {
    return depthSegments;
}
