#include <iostream>
#include <SDL2/SDL_opengl.h>
#include "App.h"
#include "Node.h"
#include "Cube.h"
#include "Cloth.h"
#include "Ball.h"
#include "SPHFluid.h"
#include "ShallowWater.h"

#define STRINGIFY(x) #x
const std::string ballVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
);
const std::string ballFragmentShader =
STRINGIFY(
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              vec3 l = normalize(vec3(0.0, 0.0, 100.0) - v_position);
              vec4 color = vec4(0.0, 0.3, 0.8, 1.0) * (max(dot(v_normal, l), 0.0) + 0.4);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
);

const string floorVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          attribute vec2 a_texCoord;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec2 v_uv;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              v_uv = a_texCoord;
              gl_Position = u_projection * pos;
          }
);
const string floorFragmentShader =
STRINGIFY(
          uniform sampler2D u_tex;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec2 v_uv;
          void main() {
              vec3 l = normalize(vec3(0.0, 0.0, 100.0) - v_position);
              vec4 color = texture2D(u_tex, v_uv) * (max(dot(v_normal, l), 0.0) + 0.4);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
);

App::App() {
    rootNode = shared_ptr<Node>(new Node());
    rootNode->name = "root";
    camera = shared_ptr<Camera>(new Camera(1.33, 0.1, 1000.0));
    camera->name = "camera";
    rootNode->addChildNode(camera);
    camera->translateTo(vec3(0.0, 2.0, 5.0));
    camera->rotateTo(vec3(M_PI * 0.5, M_PI * 0.25, 0.0));
    running = true;
    justTransitioned = false;
}

void App::setup() {
    glClearColor( 0.f, 0.f, 0.f, 1.f );
    
    glEnable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    GetGLError();
    
    // glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
    GetGLError();
    
    GLenum error = glGetError();
    if( error != GL_NO_ERROR ) {
        std::cout << "Error initializing OpenGL! " << std::endl;
    }
    
    handleKeyPress(SDLK_3, false);
}

void App::resizeTo(int width, int height) {
    // Adjust Viewport
    glViewport(0,0, width, height);
    
    // Update projection matrix
    float aspect = (float)width / (float)height;
    camera->setAspect(aspect);
}

void App::resetScene() {
    rootNode->removeAllChildren();
}

void* floorEmitterUpdate1 = &floorEmitterUpdate1;
void* floorEmitterUpdate2 = &floorEmitterUpdate2;
Uint32 timerCallback(Uint32 interval, void *param) {
    SDL_Event event;
    SDL_UserEvent userevent;
    
    userevent.type = SDL_USEREVENT;
    userevent.code = 0;
    userevent.data1 = param;
    userevent.data2 = NULL;
    
    event.type = SDL_USEREVENT;
    event.user = userevent;
    
    SDL_PushEvent(&event);
    return 0;
}
void App::handleKeyPress(SDL_Keycode key, bool repeat) {
    const float movement = 0.025;
    if (key == SDLK_UP) {
        camera->translateBy(vec3(0.0, movement, 0.0));
    } else if (key == SDLK_DOWN) {
        camera->translateBy(vec3(0.0, -movement, 0.0));
    } else if (key == SDLK_LEFT) {
        camera->translateBy(vec3(-movement, 0.0, 0.0));
    } else if (key == SDLK_RIGHT) {
        camera->translateBy(vec3(movement, 0.0, 0.0));
    } else if (key == SDLK_EQUALS) {
        camera->translateBy(vec3(0.0, 0.0, -movement));
    } else if (key == SDLK_MINUS) {
        camera->translateBy(vec3(0.0, 0.0, movement));
    } else if (key == SDLK_r) {
        camera->translateTo(vec3(0.0, 2.0, 5.0));
        camera->rotateTo(vec3(M_PI * 0.5, M_PI * 0.25, 0.0));
    } else if (key == SDLK_1) {
        resetScene();
        
        shared_ptr<Cube> cube = shared_ptr<Cube>(new Cube(5.0, 5.0, 1.0, 1, 1, 1));
        shared_ptr<Node> floor = shared_ptr<Node>(new Node());
        floor->name = "floor";
        floor->setGeometry(cube);
        floor->setTexture(shared_ptr<Texture>(new Texture("Textures/wood.jpg")));
        rootNode->addChildNode(floor);
        floor->translateTo(vec3(0.0, 0.0, -0.5));
        
        shared_ptr<Program> floorShader(new Program());
        floorShader->bindAttribute(PositionAttributeLocation, PositionAttribute);
        floorShader->bindAttribute(NormalAttributeLocation, NormalAttribute);
        floorShader->bindAttribute(TexCoordAttributeLocation, TexCoordAttribute);
        floorShader->buildProgram(floorVertexShader, floorFragmentShader);
        floor->setProgram(floorShader);
        
        shared_ptr<Cloth> cloth = shared_ptr<Cloth>(new Cloth(2.0, 2.0, 20));
        rootNode->addChildNode(cloth);
        cloth->translateTo(vec3(0.0, 0.0, 2.0));
        
        shared_ptr<Ball> ball = shared_ptr<Ball>(new Ball(0.5));
        rootNode->addChildNode(ball);
        ball->translateTo(vec3(0.5, 0.0, 1.5));
        cloth->physicsBall = ball;
        
        justTransitioned = true;
    } else if (key == SDLK_2) {
        resetScene();
        
        shared_ptr<Cube> cube = shared_ptr<Cube>(new Cube(5.0, 5.0, 1.0, 1, 1, 1));
        shared_ptr<Node> floor = shared_ptr<Node>(new Node());
        floor->name = "floor";
        floor->setGeometry(cube);
        floor->setTexture(shared_ptr<Texture>(new Texture("Textures/wood.jpg")));
        rootNode->addChildNode(floor);
        floor->translateTo(vec3(0.0, 0.0, -0.5));
        
        shared_ptr<Program> floorShader(new Program());
        floorShader->bindAttribute(PositionAttributeLocation, PositionAttribute);
        floorShader->bindAttribute(NormalAttributeLocation, NormalAttribute);
        floorShader->bindAttribute(TexCoordAttributeLocation, TexCoordAttribute);
        floorShader->buildProgram(floorVertexShader, floorFragmentShader);
        floor->setProgram(floorShader);
        
        shared_ptr<SPHFluid> fluid = shared_ptr<SPHFluid>(new SPHFluid(vec3(0.0, 0.0, 0.0), vec3(5.0, 5.0, 5.0)));
        rootNode->addChildNode(fluid);
        
        justTransitioned = true;
    } else if (key == SDLK_3) {
        resetScene();
        
        shared_ptr<Cube> cube = shared_ptr<Cube>(new Cube(5.0, 5.0, 1.0, 1, 1, 1));
        shared_ptr<Node> floor = shared_ptr<Node>(new Node());
        floor->name = "floor";
        floor->setGeometry(cube);
        floor->setTexture(shared_ptr<Texture>(new Texture("Textures/wood.jpg")));
        rootNode->addChildNode(floor);
        floor->translateTo(vec3(0.0, 0.0, -0.5));
        
        shared_ptr<Program> floorShader(new Program());
        floorShader->bindAttribute(PositionAttributeLocation, PositionAttribute);
        floorShader->bindAttribute(NormalAttributeLocation, NormalAttribute);
        floorShader->bindAttribute(TexCoordAttributeLocation, TexCoordAttribute);
        floorShader->buildProgram(floorVertexShader, floorFragmentShader);
        floor->setProgram(floorShader);
        
        shared_ptr<ShallowWater> water = shared_ptr<ShallowWater>(new ShallowWater(vec3(4.0, 1.0, 1.0), 40));
        rootNode->addChildNode(water);
        water->translateTo(vec3(0.0, 0.0, 0.52));
        
        justTransitioned = true;
    } else if (key == SDLK_SPACE) {
        running = !running;
    }
}
void App::handleKeyRelease(SDL_Keycode key) {
    
}
void App::handleMouseMove(int changeX, int changeY, int buttons) {
    if (buttons == SDL_BUTTON_LEFT) {
        // Rotate the view
        float factor = 0.005;
        camera->rotateBy(vec3(-changeY * factor, changeX * factor, 0.0));
        // camera->translateBy(vec3(-changeX * factor, changeY * factor, 0.0));
    }
}

void App::handleUserEvent(void* data) {
    
}

void App::update(float dt) {
    if (!running || justTransitioned) {
        justTransitioned = false;
        return;
    }
    rootNode->update(dt);
}

void App::draw() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);    
    
    rootNode->draw(camera->viewMatrix() * camera->projectionMatrix());
    
    GetGLError();
}