
#ifndef ShaderAttributes_h
#define ShaderAttributes_h

#include <string>

const std::string ModelViewMatrixUniform = "u_modelView";
const std::string NormalMatrixUniform    = "u_normal";
const std::string ProjectionUniform      = "u_projection";
const std::string TextureUniform         = "u_tex";

const std::string PositionAttribute = "a_position";
const std::string NormalAttribute   = "a_normal";
const std::string TexCoordAttribute = "a_texCoord";
const int PositionAttributeLocation = 0;
const int NormalAttributeLocation = 1;
const int TexCoordAttributeLocation = 2;

#endif /* ShaderAttributes_h */
